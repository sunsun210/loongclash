#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GTK3 外壳：把本地 Web 界面包成原生窗口。

选择 GTK3 而不是 GTK4 或 Electron 的原因：
  * Loongnix 25 / Debian 13 的 KDE 桌面上 GTK3 与 WebKitGTK 4.1 是 deb 源里
    已有的包，loong64 有官方编译版本，不需要 Node/Electron 这类大概率没有
    龙芯构建的运行时；
  * GTK3 API 稳定，webkit2gtk-4.1 的 Python 绑定（gir1.2-webkit2-4.1）
    在 Debian 13 里同时支持 introspection，pygobject 直接用即可。

如果没有 GTK 或 WebKit，本模块 import 就会失败，server.py 会自动降级为
「用系统浏览器打开」，功能完全一致。
"""

import os
import sys

try:
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("WebKit2", "4.1")
    from gi.repository import Gtk, WebKit2, GLib, Gdk  # noqa: F401
except Exception:  # noqa: BLE001
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        gi.require_version("WebKit2", "4.0")
        from gi.repository import Gtk, WebKit2, GLib, Gdk  # noqa: F401
    except Exception:  # noqa: BLE001
        raise ImportError("未找到 GTK3 / WebKit2 的 Python 绑定")


APP_CSS = b"""
window { background-color: #12151c; }
headerbar { background: #171b24; border-bottom: 1px solid #2b3344; }
headerbar .title { color: #e6eaf2; font-weight: 600; }
"""


class Shell(object):
    def __init__(self, url, backend, token):
        self.url = url
        self.backend = backend
        self.token = token

        self.win = Gtk.Window(title="LoongClash")
        self.win.set_default_size(1180, 780)
        self.win.set_position(Gtk.WindowPosition.CENTER)
        self.win.set_icon_name("loongclash")

        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.props.title = "LoongClash"
        header.props.subtitle = "龙芯 Clash 图形客户端"
        self.win.set_titlebar(header)

        self.status_btn = Gtk.Button(label="未连接")
        self.status_btn.set_relief(Gtk.ReliefStyle.NONE)
        self.status_btn.connect("clicked", self.on_toggle)
        header.pack_end(self.status_btn)

        self.view = WebKit2.WebView()
        settings = self.view.get_settings()
        for prop, val in (
            ("enable_javascript", True),
            ("enable_smooth_scrolling", True),
            ("enable_developer_extras", bool(os.environ.get("LOONGCLASH_DEBUG"))),
            ("enable_page_cache", False),
        ):
            try:
                settings.set_property(prop, val)
            except Exception:  # noqa: BLE001
                pass
        self.view.load_uri(url)
        self.win.add(self.view)

        self.win.connect("destroy", self.on_destroy)
        # 快捷键：F5 刷新，F12 开发者工具
        self.win.connect("key-press-event", self.on_key)

        self._tick()

    def on_key(self, _w, event):
        if event.keyval == Gdk.KEY_F5:
            self.view.reload()
            return True
        if event.keyval == Gdk.KEY_F12:
            try:
                self.view.get_inspector().show()
            except Exception:  # noqa: BLE001
                pass
            return True
        return False

    def on_toggle(self, _btn):
        js = "document.getElementById('power').click();"
        self.view.evaluate_javascript(js, -1, None, None, None, None, None) \
            if hasattr(self.view, "evaluate_javascript") else self.view.run_javascript(js, None, None, None)

    def _tick(self):
        """标题栏上的迷你状态按钮跟着内核状态走。"""
        try:
            st = self.backend.core_state()
            self.status_btn.set_label("已连接 · %d" % st["mixedPort"] if st["running"] else "未连接")
        except Exception:  # noqa: BLE001
            pass
        GLib.timeout_add_seconds(3, self._tick)

    def on_destroy(self, *_):
        try:
            self.backend.stop_core()
        except Exception:  # noqa: BLE001
            pass
        Gtk.main_quit()
        return False

    def show(self):
        provider = Gtk.CssProvider()
        try:
            provider.load_from_data(APP_CSS)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        except Exception:  # noqa: BLE001
            pass
        self.win.show_all()
        Gtk.main()


def launch(url, backend, token):
    try:
        shell = Shell(url, backend, token)
    except Exception as exc:  # noqa: BLE001
        print("GTK 窗口创建失败：%s" % exc, file=sys.stderr)
        return 2
    shell.show()
    return 0
