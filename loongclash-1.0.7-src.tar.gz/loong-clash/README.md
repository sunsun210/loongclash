# LoongClash —— 龙芯 Loongnix 25 图形化 Clash 客户端

原生支持 **loongarch64（ABI 2.0 / 新世界）** 的 Clash 图形客户端，为 Loongnix 25（Debian 13 底座）设计，也兼容其他 Debian 系发行版。

内核使用 [mihomo](https://github.com/MetaCubeX/mihomo)（Clash.Meta）官方 `linux-loong64-abi2` 构建，无需二进制翻译，龙芯 3A5000/3A6000/2K2000/2K3000 上原生运行。

## 功能

- **订阅管理**：机场订阅链接 / 本地 YAML 导入，自动解析节点数、规则数，一键更新
- **节点选择与测速**：策略组切换、批量延迟测试（Google / Cloudflare / 自定义 URL）
- **规则与连接**：规则表实时搜索、活动连接查看与断开、实时速率图
- **系统代理**：自动写入 GNOME / KDE / XFCE 桌面代理设置，无需 root
- **TUN 透明代理**：接管全部流量，支持 mixed / gvisor / system 协议栈，免 sudo 授权脚本
- **内核管理**：一键安装 mihomo 内核、GeoIP/GeoSite 数据国内镜像预下载（内核直连 GitHub 必超时）
- **日志**：应用日志 + 内核日志分级展示，出错时给出中文诊断（端口占用、GeoIP 下载失败、权限不足等）

界面为本地 Web 页（零外部依赖，离线可用）；有桌面环境时通过 GTK3 + WebKit2 显示成原生窗口，无桌面时自动退回浏览器。

## 安装

### 方式一：deb 包（推荐）

```bash
bash packaging/build-deb.sh
sudo apt install ./loongclash_*_all.deb
```

### 方式二：脚本安装

```bash
sudo bash install.sh
```

### 方式三：免安装直接跑

```bash
python3 server.py            # 桌面环境：打开 GTK 窗口
python3 server.py --headless # 无桌面：终端打印 URL，用浏览器打开
```

## 首次使用

1. 打开「设置 → 内核」，安装内核：
   - 下载 [mihomo-linux-loong64-abi2](https://github.com/MetaCubeX/mihomo/releases)（GitHub 打不开可用 `https://ghfast.top/` 前缀镜像），解压后把文件路径填进去点「安装内核」；
   - 建议顺手点「预下载数据」把 GeoIP / GeoSite 下好。
2. 打开「订阅」页，粘贴机场订阅链接点「导入订阅」。
3. 点左上角电源启动。浏览器/程序走 `127.0.0.1:7890`（混合端口），或在设置里打开「系统代理」一键写入桌面环境。
4. 需要 TUN 全局接管时：先执行一次 `sudo bash packaging/grant-permissions.sh`，然后在设置里开「启用 TUN」。

## 目录结构

```
server.py                  后端（Python 标准库，零第三方依赖）
gtk_shell.py               GTK3 + WebKit2 窗口外壳（可选，缺失自动降级浏览器）
ui/                        前端（原生 HTML/CSS/JS，无 CDN）
packaging/build-deb.sh     构建 .deb
packaging/grant-permissions.sh  TUN 免 sudo 授权
packaging/loongclash.svg   应用图标
install.sh                 一键安装脚本
```

数据目录：`~/.config/LoongClash/`（profiles 订阅、core 内核、runtime 运行配置与日志）。

## 常见问题

| 现象 | 处理 |
| --- | --- |
| 启动报「can't download MMDB」 | 设置 → 内核 → 预下载数据（内核自己连 GitHub 会超时退出） |
| 端口被占用 | 设置里改混合端口；`sudo ss -tlnp \| grep 7890` 查占用者 |
| TUN 开不了 | 先跑 `sudo bash packaging/grant-permissions.sh`；确认 `/dev/net/tun` 存在 |
| 窗口空白 / WebKit 缺失 | `sudo apt install gir1.2-webkit2-4.1`，或直接浏览器模式 |
| 订阅更新失败 | 检查链接是否需要全局代理才能访问；可先用其他渠道把 YAML 下载为本地导入 |

## 许可

GPL-3.0。内核 mihomo 归其作者所有。
