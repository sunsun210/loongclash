#!/bin/bash
# LoongClash 诊断脚本 v2：重点排查「能启动但没有连接」
OUT="$HOME/loongclash-diag.txt"
: > "$OUT"
say() { echo "$@" | tee -a "$OUT"; }
sec() { echo "" | tee -a "$OUT"; echo "===== $* =====" | tee -a "$OUT"; }
HIT() { grep -E "^$1:" "$CF" 2>/dev/null; }

CF="$HOME/.config/LoongClash/runtime/config.yaml"
LOG="$HOME/.config/LoongClash/core.log"

sec "0. 基本信息"
say "时间: $(date)"
say "架构: $(uname -m)   内核: $(uname -r)"
say "系统: $(grep PRETTY_NAME /etc/os-release 2>/dev/null | cut -d'"' -f2)"
say "桌面: ${XDG_CURRENT_DESKTOP:-未设置}"

sec "1. 程序版本"
for p in /opt/loongclash/server.py "$HOME/loong-clash/server.py"; do
  [ -f "$p" ] && say "server.py: $p  →  版本 $(grep -oP 'APP_VERSION = "\K[^"]+' "$p")"
done
say "运行中进程:"; ps -eo pid,etime,cmd | grep -E "[s]erver\.py|[m]ihomo" | sed 's/^/  /' | tee -a "$OUT"

sec "2. 当前配置的端口"
if [ -f "$CF" ]; then
  grep -nE "^(mixed-port|port|socks-port|allow-lan|external-controller|mode):" "$CF" | sed 's/^/  /' | tee -a "$OUT"
else
  say "  !! config.yaml 不存在"
fi

sec "3. 端口监听（关键：7890 到底谁在听）"
(ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null) | grep -E ":7890|:7891|:7897" | sed 's/^/  /' | tee -a "$OUT"
say "  --- 若无输出，说明没有任何程序在监听 7890 ---"

sec "4. 内核是否报错（重点看 bind / error / fatal）"
grep -iE "error|fatal|warn|bind" "$LOG" 2>/dev/null | tail -15 | sed 's/^/  /' | tee -a "$OUT" || say "  日志不存在"

sec "5. 内核启动过程完整日志（最后 25 行）"
tail -25 "$LOG" 2>/dev/null | sed 's/^/  /' | tee -a "$OUT"

sec "6. 直接测试代理端口"
if (exec 3<>/dev/tcp/127.0.0.1/7890) 2>/dev/null; then
  exec 3<&- 3>&-
  say "  7890 可连接 ✅"
  say "  经代理访问测试地址："
  curl -s -o /dev/null -m 12 -w "    HTTP=%{http_code} 耗时=%{time_total}s\n" \
       -x http://127.0.0.1:7890 http://www.gstatic.com/generate_204 2>&1 | tee -a "$OUT"
else
  say "  !! 7890 无法连接 —— 内核没在监听，或端口被改"
fi

sec "7. 系统代理状态（GNOME/XFCE 用 gsettings）"
if command -v gsettings >/dev/null 2>&1; then
  say "  mode = $(gsettings get org.gnome.system.proxy mode 2>/dev/null)"
  say "  http = $(gsettings get org.gnome.system.proxy.http host 2>/dev/null):$(gsettings get org.gnome.system.proxy.http port 2>/dev/null)"
  say "  https= $(gsettings get org.gnome.system.proxy.https host 2>/dev/null):$(gsettings get org.gnome.system.proxy.https port 2>/dev/null)"
  say "  socks= $(gsettings get org.gnome.system.proxy.socks host 2>/dev/null):$(gsettings get org.gnome.system.proxy.socks port 2>/dev/null)"
else
  say "  没有 gsettings"
fi
if command -v kreadconfig6 >/dev/null 2>&1 || command -v kreadconfig5 >/dev/null 2>&1; then
  KR=$(command -v kreadconfig6 || command -v kreadconfig5)
  say "  KDE ProxyType = $($KR --file kioslaverc --group 'Proxy Settings' --key ProxyType 2>/dev/null)"
  say "  KDE httpProxy = $($KR --file kioslaverc --group 'Proxy Settings' --key httpProxy 2>/dev/null)"
fi
say "  环境变量 http_proxy=${http_proxy:-未设置} https_proxy=${https_proxy:-未设置}"

sec "8. 通过内核 API 查当前节点与连接"
if [ -f "$CF" ]; then
  EC=$(grep -m1 "^external-controller:" "$CF" | awk '{print $2}')
  SC=$(grep -m1 "^secret:" "$CF" | sed -E 's/^secret:[[:space:]]*//; s/^"//; s/"$//')
  if [ -n "$EC" ]; then
    say "  API $EC"
    say "  当前选中节点："
    curl -s -m 5 -H "Authorization: Bearer $SC" "http://$EC/proxies" 2>/dev/null | \
      python3 -c "
import json,sys
try:
    d=json.load(sys.stdin).get('proxies',{})
    for k,v in d.items():
        if v.get('type') in ('Selector','URLTest','Fallback'):
            print('    %-16s → %s' % (k, v.get('now')))
except Exception as e:
    print('    解析失败', e)
" 2>/dev/null | tee -a "$OUT"
    say "  当前连接数："
    curl -s -m 5 -H "Authorization: Bearer $SC" "http://$EC/connections" 2>/dev/null | \
      python3 -c "
import json,sys
try:
    d=json.load(sys.stdin); c=d.get('connections') or []
    print('    共 %d 条' % len(c))
    for x in c[:5]:
        m=x.get('metadata',{})
        print('      %s:%s  via %s' % (m.get('host') or m.get('destinationIP'), m.get('destinationPort'), '→'.join(x.get('chains') or [])))
except Exception as e:
    print('    解析失败', e)
" 2>/dev/null | tee -a "$OUT"
  fi
fi

sec "9. 节点延迟（测一次看节点通不通）"
if [ -f "$CF" ]; then
  EC=$(grep -m1 "^external-controller:" "$CF" | awk '{print $2}')
  SC=$(grep -m1 "^secret:" "$CF" | sed -E 's/^secret:[[:space:]]*//; s/^"//; s/"$//')
  curl -s -m 20 -H "Authorization: Bearer $SC" \
    "http://$EC/group/PROXY/delay?url=http://www.gstatic.com/generate_204&timeout=5000" \
    2>/dev/null | head -c 600 | sed 's/^/  /' | tee -a "$OUT"; say ""
fi

sec "10. 最近流量统计"
if [ -f "$CF" ]; then
  EC=$(grep -m1 "^external-controller:" "$CF" | awk '{print $2}')
  SC=$(grep -m1 "^secret:" "$CF" | sed -E 's/^secret:[[:space:]]*//; s/^"//; s/"$//')
  say "  上传累计: $(curl -s -m 5 -H "Authorization: Bearer $SC" "http://$EC/traffic/upload/total" 2>/dev/null)"
  say "  下载累计: $(curl -s -m 5 -H "Authorization: Bearer $SC" "http://$EC/traffic/download/total" 2>/dev/null)"
fi

say ""
say "=============================================="
say "诊断完成: $OUT"
say "请把上面全部输出（或这个文件）发给我"
