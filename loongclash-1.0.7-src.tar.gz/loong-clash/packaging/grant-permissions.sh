#!/bin/bash
# LoongClash 授权脚本 —— 让普通用户能开启 TUN 模式
# 用法：sudo bash grant-permissions.sh
#
# 做两件事：
#   1. 确保 tun 内核模块开机自动加载
#   2. 给 mihomo 内核 setcap cap_net_admin，让 TUN 不需要每次 sudo

set -e

if [ "$(id -u)" -ne 0 ]; then
  echo "请用 sudo 运行"; exit 1
fi

echo "==> 加载 tun 模块并设置开机自动加载"
modprobe tun 2>/dev/null || true
if [ -f /etc/modules ] && ! grep -qx tun /etc/modules; then
  echo tun >> /etc/modules
fi

CORE="$HOME/.config/LoongClash/core/mihomo"
[ -f "$CORE" ] || CORE="/opt/loongclash/core/mihomo"
if [ -f "$CORE" ]; then
  echo "==> 给内核授予网络权限: $CORE"
  setcap cap_net_admin,cap_net_bind_service=+ep "$CORE" \
    && echo "    完成，TUN 现在无需 sudo 即可开启" \
    || echo "    setcap 失败（可能缺少 libcap），请执行: apt install libcap2-bin"
else
  echo "    未找到内核文件，请先在应用「设置 → 内核」里安装内核后再运行本脚本"
fi

echo "==> 完成"
