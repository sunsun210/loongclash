#!/bin/bash
# 构建 LoongClash 的 .deb 安装包
# 在 Loongnix 25（或任何有 dpkg-deb 的 Debian 系）上运行：
#     bash packaging/build-deb.sh
# 产物：loongclash_<版本>_all.deb
set -e
cd "$(dirname "$0")/.."

VER=$(grep -oP 'APP_VERSION = "\K[^"]+' server.py)
OUT="loongclash_${VER}_all.deb"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

D="$WORK/loongclash"
mkdir -p "$D/DEBIAN" "$D/opt/loongclash" "$D/usr/local/bin" \
         "$D/usr/share/applications" "$D/usr/share/icons/hicolor/scalable/apps" \
         "$D/usr/share/doc/loongclash"

cp -r server.py gtk_shell.py ui "$D/opt/loongclash/"
cp README.md "$D/usr/share/doc/loongclash/"

cat > "$D/usr/local/bin/loongclash" <<'EOF'
#!/bin/bash
exec python3 /opt/loongclash/server.py "$@"
EOF
chmod +x "$D/usr/local/bin/loongclash"

cp packaging/loongclash.svg "$D/usr/share/icons/hicolor/scalable/apps/"
cat > "$D/usr/share/applications/loongclash.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=LoongClash
Name[zh_CN]=LoongClash 代理
Comment=龙芯图形化 Clash 客户端
Exec=/usr/local/bin/loongclash
Icon=loongclash
Terminal=false
Categories=Network;
Keywords=clash;proxy;vpn;代理;
StartupNotify=true
EOF

SIZE=$(du -sk "$D" | cut -f1)
cat > "$D/DEBIAN/control" <<EOF
Package: loongclash
Version: $VER
Section: net
Priority: optional
Architecture: all
Depends: python3 (>= 3.10)
Recommends: python3-gi, gir1.2-gtk-3.0, gir1.2-webkit2-4.1, libcap2-bin
Suggests: sudo
Installed-Size: $SIZE
Maintainer: LoongClash contributors
Description: 龙芯 Loongnix 25 图形化 Clash/mihomo 客户端
 内置内核管理、订阅管理、节点测速、规则与连接查看、
 系统代理与 TUN 透明代理。前端为本地 Web 界面，
 桌面上通过 GTK3 + WebKit2 显示，无桌面时自动退回浏览器。
EOF

cat > "$D/DEBIAN/postinst" <<'EOF'
#!/bin/bash
set -e
modprobe tun 2>/dev/null || true
CORE=/opt/loongclash/core/mihomo
if [ -f "$CORE" ]; then
  setcap cap_net_admin,cap_net_bind_service=+ep "$CORE" 2>/dev/null || true
fi
exit 0
EOF
chmod +x "$D/DEBIAN/postinst"

dpkg-deb --build --root-owner-group "$D" "$OUT"
echo "构建完成: $OUT"
echo "安装: sudo apt install ./$OUT  或  sudo dpkg -i $OUT"
