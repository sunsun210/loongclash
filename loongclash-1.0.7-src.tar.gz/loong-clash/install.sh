#!/bin/bash
# LoongClash 一键安装脚本（Loongnix 25 / Debian 13, loongarch64）
set -e

PREFIX=/opt/loongclash
BIN=/usr/local/bin/loongclash
DESKTOP=/usr/share/applications/loongclash.desktop
ICON=/usr/share/icons/hicolor/scalable/apps/loongclash.svg

if [ "$(id -u)" -ne 0 ]; then
  echo "请用 sudo 运行：sudo bash install.sh"
  exit 1
fi

echo "==> 安装程序文件到 $PREFIX"
mkdir -p "$PREFIX"
cp -r server.py gtk_shell.py ui "$PREFIX/"

echo "==> 创建启动命令 $BIN"
cat > "$BIN" <<'EOF'
#!/bin/bash
# 后台运行时无 DISPLAY，走浏览器模式；桌面环境里打开 GTK 窗口
exec python3 /opt/loongclash/server.py "$@"
EOF
chmod +x "$BIN"

echo "==> 安装桌面图标与菜单项"
cp packaging/loongclash.svg "$ICON" 2>/dev/null || true
cat > "$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=LoongClash
Name[zh_CN]=LoongClash 代理
Comment=龙芯图形化 Clash 客户端
Exec=$BIN
Icon=loongclash
Terminal=false
Categories=Network;
Keywords=clash;proxy;vpn;代理;
StartupNotify=true
EOF

echo "==> 安装依赖（已装则跳过）"
MISSING=""
python3 -c "import gi" 2>/dev/null || MISSING="$MISSING python3-gi python3-gi-cairo gir1.2-gtk-3.0"
python3 - <<'PY' 2>/dev/null || MISSING="$MISSING gir1.2-webkit2-4.1"
import gi
gi.require_version("WebKit2", "4.1")
from gi.repository import WebKit2
PY
if [ -n "$MISSING" ]; then
  echo "    安装:$MISSING"
  apt-get install -y $MISSING || echo "    警告：依赖安装失败，将退回浏览器模式（功能不受影响）"
fi

# 给 TUN 准备 tun 模块（失败不影响安装）
modprobe tun 2>/dev/null || true

echo
echo "安装完成！在应用菜单里找 LoongClash，或终端执行：loongclash"
echo "首次使用：打开「订阅」页导入你的机场订阅链接，然后点左上角电源启动。"
