'use strict';

/* LoongClash 前端逻辑：纯原生 JS，不依赖任何 CDN，内网/离线可用 */

const TOKEN = (() => {
  const m = location.hash.match(/token=([A-Za-z0-9]+)/);
  return m ? m[1] : '';
})();

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

const state = {
  view: 'dash',
  overview: null,
  proxies: { groups: [], nodes: [] },
  profiles: { items: [], current: '' },
  editing: null,
  running: false,
  traffic: { up: 0, down: 0 },
  sparkUp: [],
  sparkDown: [],
  settingsDirty: false,
  logs: [],
  showLogs: false,
  autoScroll: true,
};

/* ── 网络 ─────────────────────────────────── */
async function api(path, opts) {
  opts = opts || {};
  const init = { method: opts.method || 'GET', headers: { 'X-LoongClash-Token': TOKEN } };
  if (opts.body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let payload = null;
  try { payload = await res.json(); } catch (e) { payload = { ok: false, error: '响应解析失败' }; }
  if (!res.ok || !payload || payload.ok === false) {
    throw new Error((payload && payload.error) || ('请求失败 ' + res.status));
  }
  return payload.data;
}

let toastTimer = null;
function toast(msg, isErr) {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast show' + (isErr ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = 'toast'; }, isErr ? 4200 : 2200);
}

function confirmDialog(title, body, okText) {
  return new Promise((resolve) => {
    const modal = $('#modal');
    $('#modal-title').textContent = title;
    $('#modal-body').textContent = body || '';
    $('#modal-ok').textContent = okText || '确定';
    modal.hidden = false;
    const done = (v) => { modal.hidden = true; $('#modal-ok').onclick = null; $('#modal-cancel').onclick = null; resolve(v); };
    $('#modal-ok').onclick = () => done(true);
    $('#modal-cancel').onclick = () => done(false);
  });
}

/* ── 格式化 ───────────────────────────────── */
function bytes(n) {
  n = Number(n) || 0;
  if (n < 1024) return n.toFixed(0) + ' B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return n.toFixed(n >= 100 ? 0 : 1) + ' ' + u[i];
}
function rate(n) { return bytes(n) + '/s'; }
function dur(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600),
    m = Math.floor((sec % 3600) / 60), s = sec % 60;
  if (d) return d + ' 天 ' + h + ' 时';
  if (h) return h + ' 时 ' + m + ' 分';
  if (m) return m + ' 分 ' + s + ' 秒';
  return s + ' 秒';
}
function timeAgo(ts) {
  if (!ts) return '—';
  const diff = Math.floor(Date.now() / 1000) - ts;
  if (diff < 60) return '刚刚';
  if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
  if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前';
  return Math.floor(diff / 86400) + ' 天前';
}
function latClass(d) {
  if (d === undefined || d === null) return 'lat-5';
  if (typeof d !== 'number' || d <= 0) return 'lat-5';
  if (d < 100) return 'lat-0';
  if (d < 200) return 'lat-1';
  if (d < 400) return 'lat-2';
  if (d < 800) return 'lat-3';
  return 'lat-4';
}
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ── 视图切换 ─────────────────────────────── */
const CRUMBS = { dash: '概览', proxies: '节点', rules: '规则', conns: '连接', profiles: '订阅', settings: '设置', logs: '日志' };
function switchView(view) {
  state.view = view;
  $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  $$('.view').forEach((v) => { v.hidden = (v.id !== 'view-' + view); });
  $('#crumb').textContent = CRUMBS[view] || view;
  if (view === 'proxies') loadProxies();
  if (view === 'rules') loadRules();
  if (view === 'conns') loadConns();
  if (view === 'profiles') loadProfiles();
  if (view === 'settings') loadSettings();
  if (view === 'logs') state.showLogs = true;
}
$$('.nav-item').forEach((b) => b.addEventListener('click', () => switchView(b.dataset.view)));

/* ── 概览 ─────────────────────────────────── */
function drawSpark() {
  const cv = $('#spark');
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth || 420, h = 110;
  if (cv.width !== w * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const up = state.sparkUp, down = state.sparkDown;
  const n = Math.max(up.length, 2);
  const maxV = Math.max(1024, ...down, ...up);
  const step = w / (n - 1 || 1);

  ctx.strokeStyle = 'rgba(255,255,255,.05)';
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i++) {
    const y = (h / 4) * i;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  const line = (arr, color, fill) => {
    if (arr.length < 2) return;
    ctx.beginPath();
    arr.forEach((v, i) => {
      const x = i * step, y = h - 6 - (v / maxV) * (h - 16);
      i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
    });
    ctx.strokeStyle = color; ctx.lineWidth = 1.8; ctx.stroke();
    if (fill) {
      ctx.lineTo((arr.length - 1) * step, h); ctx.lineTo(0, h); ctx.closePath();
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, fill); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.fill();
    }
  };
  line(down, '#4b9cf5', 'rgba(75,156,245,.22)');
  line(up, '#e8a33d', 'rgba(232,163,61,.16)');
}

function renderOverview() {
  const d = state.overview;
  if (!d) return;
  const core = d.core || {};
  state.running = !!core.running;

  const power = $('#power');
  power.classList.toggle('on', state.running);
  $('.power-label', power).textContent = state.running ? '已连接' : '未连接';
  $('.power-hint', power).textContent = state.running ? '点击停止' : '点击启动';

  $('#mode-switch').hidden = !state.running;
  $('#btn-restart').hidden = !state.running;
  $$('#mode-switch button').forEach((b) => b.classList.toggle('active', b.dataset.mode === (d.mode || 'rule')));

  const hs = $('#hero-state');
  hs.textContent = state.running ? '代理运行中' : '内核未运行';
  hs.className = 'hero-state ' + (state.running ? 'on' : 'off');
  $('#hero-sub').textContent = state.running
    ? '混合端口 ' + (d.mixedPort || (d.settings && d.settings.mixedPort) || '—') + ' · 模式 ' + ({ rule: '规则', global: '全局', direct: '直连' }[d.mode] || d.mode)
    : (core.error || '导入订阅后点击左上角电源启动');

  const chips = [];
  const sp = d.systemProxy || {};
  chips.push('<span class="chip ' + (sp.enabled ? 'ok' : '') + '">系统代理 ' + (sp.enabled ? '已开启' : '关闭') + '</span>');
  const tun = d.settings && d.settings.tun && d.settings.tun.enable;
  const tunCap = (d.permissions.caps || []).find((c) => c.key === 'tun') || {};
  chips.push('<span class="chip ' + (tun && tunCap.ok ? 'ok' : tun ? 'warn' : '') + '">TUN ' +
    (tun ? (tunCap.ok ? '已开启' : '已开启(权限不足)') : '关闭') + '</span>');
  chips.push('<span class="chip">订阅 ' + (d.profileCount || 0) + ' 个</span>');
  if (core.version) chips.push('<span class="chip">' + esc(core.version.split(' ').slice(0, 3).join(' ')) + '</span>');
  $('#hero-chips').innerHTML = chips.join('');

  $('#m-uptime').textContent = state.running ? dur(core.uptime) : '—';
  $('#m-conns').textContent = state.running ? (d.traffic ? d.traffic.conns : 0) : '—';
  $('#m-mem').textContent = state.running ? bytes(d.traffic ? d.traffic.mem : 0) : '—';
  $('#m-port').textContent = (d.settings && d.settings.mixedPort) || '—';

  renderWarn(d);
  renderEnv();
}

function renderWarn(d) {
  const box = $('#dash-warn');
  if (!box) return;
  const msg = (d && d.warn) || '';
  if (!state.running || !msg) {
    box.hidden = true;
    return;
  }
  const txt = $('#dash-warn-text');
  if (txt) txt.textContent = msg;
  box.hidden = false;
}

function renderEnv() {
  const d = state.overview || {};
  const core = d.core || {};
  const perms = d.permissions || {};
  const items = [
    ['运行架构', perms.arch || '—'],
    ['内核', core.version || '未安装'],
    ['内核路径', core.path || '—'],
    ['运行身份', perms.isRoot ? 'root' : '普通用户'],
    ['API 端口', core.apiPort || '—'],
    ['桌面环境', (d.systemProxy && d.systemProxy.desktop) || '—'],
  ];
  $('#env-list').innerHTML = items.map(([k, v]) =>
    '<div class="env-item"><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>').join('');
}

function renderDashGroups() {
  const groups = state.proxies.groups.slice(0, 4);
  const box = $('#dash-groups');
  if (!groups.length) {
    box.innerHTML = '<div class="empty">' + (state.running ? '正在读取策略组…' : '启动内核后显示节点') + '</div>';
    return;
  }
  box.innerHTML = groups.map((g) => {
    const nodes = g.all.slice(0, 12).map((name) => {
      const n = state.proxies.nodes.find((x) => x.name === name) || {};
      return nodeChip(name, n.delay, name === g.now, g.name);
    }).join('');
    return '<div class="group"><div class="group-head"><b>' + esc(g.name) + '</b>' +
      '<span class="type">' + esc(g.type) + '</span>' +
      '<span class="now">当前 <b>' + esc(g.now || '—') + '</b></span></div>' +
      '<div class="nodes">' + nodes + '</div></div>';
  }).join('');
}

function nodeChip(name, delay, active, group) {
  const cls = 'node' + (active ? ' active' : '') + ' ' + latClass(delay);
  const bars = [0, 1, 2, 3].map((i) => {
    const on = typeof delay === 'number' && delay > 0 &&
      delay < [100, 200, 400, 800][i] ? ' on' : '';
    return '<i class="node-dot' + on + '"></i>';
  }).join('');
  const label = typeof delay === 'number' && delay > 0 ? delay + 'ms' : (delay === 0 ? '超时' : '—');
  return '<div class="' + cls + '" data-group="' + esc(group) + '" data-name="' + esc(name) + '">' +
    '<span class="node-name" title="' + esc(name) + '">' + esc(name) + '</span>' +
    '<span class="node-dots node-dot-wrap">' + bars + '</span>' +
    '<span class="delay">' + label + '</span></div>';
}

document.addEventListener('click', async (ev) => {
  const node = ev.target.closest('.node');
  if (!node) return;
  const group = node.dataset.group, name = node.dataset.name;
  try {
    await api('/api/proxy/select', { method: 'PUT', body: { group, name } });
    toast('已切换到 ' + name);
    loadProxies();
  } catch (e) { toast(e.message, true); }
});

$('#power').addEventListener('click', async () => {
  const btn = $('#power');
  btn.classList.add('busy');
  try {
    if (state.running) {
      await api('/api/core/stop', { method: 'POST' });
      toast('已停止');
    } else {
      await api('/api/core/start', { method: 'POST' });
      toast('已启动');
    }
  } catch (e) {
    toast(e.message, true);
  } finally {
    btn.classList.remove('busy');
    refreshOverview();
  }
});

$('#btn-restart').addEventListener('click', async () => {
  try { await api('/api/core/restart', { method: 'POST' }); toast('已重启'); }
  catch (e) { toast(e.message, true); }
  refreshOverview();
});

$$('#mode-switch button').forEach((b) => b.addEventListener('click', async () => {
  try {
    await api('/api/mode', { method: 'PUT', body: { mode: b.dataset.mode } });
    toast('模式已切换为 ' + b.textContent);
    refreshOverview();
  } catch (e) { toast(e.message, true); }
}));

$('#btn-latency-all').addEventListener('click', async () => {
  const g = state.proxies.groups[0];
  if (!g) return toast('没有可测速的策略组', true);
  await testGroupDelay(g.name);
});

/* ── 节点页 ───────────────────────────────── */
async function loadProxies() {
  if (!state.running) {
    $('#groups').innerHTML = '<div class="empty">内核未运行，启动后在这里选择节点</div>';
    renderDashGroups();
    return;
  }
  try {
    state.proxies = await api('/api/proxies');
  } catch (e) {
    $('#groups').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    return;
  }
  const box = $('#groups');
  if (!state.proxies.groups.length) {
    box.innerHTML = '<div class="empty">当前配置里没有策略组</div>';
  } else {
    box.innerHTML = state.proxies.groups.map((g) => {
      const nodes = g.all.map((name) => {
        const n = state.proxies.nodes.find((x) => x.name === name) || {};
        return nodeChip(name, n.delay, name === g.now, g.name);
      }).join('');
      return '<div class="group"><div class="group-head"><b>' + esc(g.name) + '</b>' +
        '<span class="type">' + esc(g.type) + '</span>' +
        '<span class="now">当前 <b>' + esc(g.now || '—') + '</b></span>' +
        '<button class="btn ghost small" data-delay-group="' + esc(g.name) + '">测速</button></div>' +
        '<div class="nodes">' + nodes + '</div></div>';
    }).join('');
  }
  $$('[data-delay-group]', box).forEach((b) =>
    b.addEventListener('click', () => testGroupDelay(b.dataset.delayGroup)));
  renderDashGroups();
}

async function testGroupDelay(group) {
  const url = $('#delay-url').value;
  toast('正在测速：' + group);
  try {
    const r = await api('/api/proxy/delay', { method: 'POST', body: { group, url, timeout: 5000 } });
    let ok = 0;
    Object.entries(r.results || {}).forEach(([name, v]) => {
      const n = state.proxies.nodes.find((x) => x.name === name);
      if (!n) return;
      if (typeof v === 'number' && v > 0) { n.delay = v; ok++; } else { n.delay = 0; }
    });
    await loadProxies();
    toast('测速完成，可用节点 ' + ok + ' 个');
  } catch (e) { toast(e.message, true); }
}

$('#btn-delay-group').addEventListener('click', () => {
  const g = state.proxies.groups[0];
  if (!g) return toast('没有可测速的策略组', true);
  testGroupDelay(g.name);
});

/* ── 规则页 ───────────────────────────────── */
let rulesCache = [];
async function loadRules() {
  if (!state.running) { $('#rules-table tbody').innerHTML = '<tr><td colspan="3"><div class="empty">内核未运行</div></td></tr>'; return; }
  try {
    const r = await api('/api/rules');
    rulesCache = r.items;
    $('#rules-count').textContent = '共 ' + r.total + ' 条';
    renderRules();
  } catch (e) { toast(e.message, true); }
}
function renderRules() {
  const q = ($('#rules-search').value || '').toLowerCase();
  const list = q ? rulesCache.filter((r) =>
    (r.type + ' ' + r.payload + ' ' + r.proxy).toLowerCase().includes(q)) : rulesCache;
  $('#rules-table tbody').innerHTML = list.slice(0, 800).map((r) =>
    '<tr><td><span class="tag">' + esc(r.type) + '</span></td>' +
    '<td class="mono">' + esc(r.payload) + '</td>' +
    '<td>' + esc(r.proxy) + '</td></tr>').join('') ||
    '<tr><td colspan="3"><div class="empty">没有匹配的规则</div></td></tr>';
}
$('#rules-search').addEventListener('input', renderRules);

/* ── 连接页 ───────────────────────────────── */
async function loadConns() {
  if (!state.running) { $('#conns-table tbody').innerHTML = '<tr><td colspan="6"><div class="empty">内核未运行</div></td></tr>'; return; }
  try {
    const r = await api('/api/connections');
    $('#conns-count').textContent = '共 ' + r.total + ' 条 · ↑' + bytes(r.upload) + ' ↓' + bytes(r.download);
    $('#conns-table tbody').innerHTML = r.items.map((c) =>
      '<tr><td class="mono">' + esc(c.host || c.dest) + '</td>' +
      '<td class="muted">' + esc((c.network || []).join(' → ')) + '</td>' +
      '<td><span class="tag">' + esc(c.rule || '-') + '</span></td>' +
      '<td class="muted">' + bytes(c.upload) + '</td>' +
      '<td class="muted">' + bytes(c.download) + '</td>' +
      '<td><button class="btn ghost small" data-kill="' + esc(c.id) + '">断开</button></td></tr>').join('') ||
      '<tr><td colspan="6"><div class="empty">暂无活动连接</div></td></tr>';
    $$('[data-kill]').forEach((b) => b.addEventListener('click', async () => {
      await api('/api/connections/close', { method: 'POST', body: { id: b.dataset.kill } });
      loadConns();
    }));
  } catch (e) { toast(e.message, true); }
}
$('#btn-close-all').addEventListener('click', async () => {
  if (!await confirmDialog('断开全部连接', '将关闭当前所有代理连接，应用会自动重连。')) return;
  await api('/api/connections/close', { method: 'POST', body: {} });
  loadConns();
});

/* ── 订阅页 ───────────────────────────────── */
async function loadProfiles() {
  try {
    state.profiles = await api('/api/profiles');
  } catch (e) { toast(e.message, true); return; }
  const items = state.profiles.items || [];
  const box = $('#profile-list');
  if (!items.length) {
    box.innerHTML = '<div class="empty">还没有订阅，把机场订阅链接粘贴到上面</div>';
    return;
  }
  box.innerHTML = items.map((p) => {
    const cur = p.id === state.profiles.current;
    return '<div class="profile ' + (cur ? 'current' : '') + '">' +
      '<div class="p-main"><div class="p-name">' + esc(p.name) +
      (cur ? '<span class="pill">使用中</span>' : '') +
      '<span class="tag">' + (p.kind === 'remote' ? '订阅' : '本地') + '</span></div>' +
      '<div class="p-meta">' + (p.proxies || 0) + ' 个节点 · ' + (p.rules || 0) + ' 条规则 · ' +
      bytes(p.size || 0) + ' · 更新于 ' + timeAgo(p.updated) +
      (p.url ? ' · ' + esc(p.url.slice(0, 60)) : '') + '</div></div>' +
      '<button class="btn small ' + (cur ? 'ghost' : 'primary') + '" data-use="' + p.id + '"' + (cur ? ' disabled' : '') + '>启用</button>' +
      (p.kind === 'remote' ? '<button class="btn ghost small" data-update="' + p.id + '">更新</button>' : '') +
      '<button class="btn ghost small" data-edit="' + p.id + '">编辑</button>' +
      '<button class="btn danger small" data-del="' + p.id + '">删除</button>' +
      '</div>';
  }).join('');

  $$('[data-use]', box).forEach((b) => b.addEventListener('click', async () => {
    try { await api('/api/profile/select', { method: 'POST', body: { id: b.dataset.use } }); toast('已启用'); }
    catch (e) { toast(e.message, true); }
    loadProfiles(); refreshOverview();
  }));
  $$('[data-update]', box).forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true; b.textContent = '更新中';
    try { await api('/api/profile/update', { method: 'POST', body: { id: b.dataset.update } }); toast('订阅已更新'); }
    catch (e) { toast(e.message, true); }
    loadProfiles();
  }));
  $$('[data-edit]', box).forEach((b) => b.addEventListener('click', () => openEditor(b.dataset.edit)));
  $$('[data-del]', box).forEach((b) => b.addEventListener('click', async () => {
    if (!await confirmDialog('删除订阅', '删除后无法恢复，确认继续？', '删除')) return;
    await api('/api/profile/delete', { method: 'POST', body: { id: b.dataset.del } });
    if (state.editing === b.dataset.del) closeEditor();
    loadProfiles(); refreshOverview();
  }));
}

async function openEditor(id) {
  try {
    const r = await api('/api/profile/content?id=' + encodeURIComponent(id));
    state.editing = id;
    const ed = $('#conf-editor');
    ed.disabled = false;
    ed.value = r.content;
    $('#btn-save-conf').disabled = false;
    const p = (state.profiles.items || []).find((x) => x.id === id);
    $('#edit-hint').textContent = '正在编辑：' + (p ? p.name : id);
    ed.scrollIntoView({ behavior: 'smooth', block: 'center' });
  } catch (e) { toast(e.message, true); }
}
function closeEditor() {
  state.editing = null;
  const ed = $('#conf-editor');
  ed.value = ''; ed.disabled = true;
  $('#btn-save-conf').disabled = true;
  $('#edit-hint').textContent = '选择上面的配置文件进行编辑';
}

$('#btn-save-conf').addEventListener('click', async () => {
  if (!state.editing) return;
  try {
    await api('/api/profile/save', { method: 'POST', body: { id: state.editing, content: $('#conf-editor').value } });
    toast('已保存并应用');
    loadProfiles();
  } catch (e) { toast(e.message, true); }
});

$('#btn-add-sub').addEventListener('click', async () => {
  const url = $('#sub-url').value.trim();
  const name = $('#sub-name').value.trim();
  if (!url) return toast('请填写订阅链接', true);
  const btn = $('#btn-add-sub');
  btn.disabled = true; btn.textContent = '导入中…';
  try {
    await api('/api/profile/add', { method: 'POST', body: { url, name } });
    $('#sub-url').value = ''; $('#sub-name').value = '';
    toast('订阅导入成功');
    loadProfiles(); refreshOverview();
  } catch (e) { toast(e.message, true); }
  finally { btn.disabled = false; btn.textContent = '导入订阅'; }
});

$('#btn-import-file').addEventListener('click', async () => {
  try {
    const r = await api('/api/pick-file');
    if (!r.path) return toast('未选择文件', true);
    await api('/api/profile/add', { method: 'POST', body: { path: r.path } });
    toast('已导入本地配置');
    loadProfiles(); refreshOverview();
  } catch (e) { toast(e.message, true); }
});

/* ── 设置页 ───────────────────────────────── */
async function loadSettings() {
  try {
    const [s, perms, co] = await Promise.all([
      api('/api/settings'), api('/api/permissions'), api('/api/core'),
    ]);
    const tun = s.tun || {}, sp = s.systemProxy || {}, dns = s.dns || {};
    $('#set-port').value = s.mixedPort || 7890;
    $('#set-lan').checked = !!s.allowLan;
    $('#set-ipv6').checked = !!s.ipv6;
    $('#set-sysproxy').checked = !!sp.enable;
    $('#set-tun').checked = !!tun.enable;
    $('#set-tun-stack').value = tun.stack || 'mixed';
    $('#set-tun-mtu').value = tun.mtu || 9000;
    $('#set-dns-ns').value = (dns.nameserver || []).join(', ');
    $('#set-dns-fb').value = (dns.fallback || []).join(', ');

    const tunCap = (perms.caps || []).find((c) => c.key === 'tun') || {};
    $('#tun-cap').textContent = tunCap.detail || '';

    $('#core-env').innerHTML = [
      ['内核文件', co.path || '未安装'],
      ['版本', co.version || '—'],
      ['运行状态', co.running ? '运行中（PID ' + co.pid + '）' : '已停止'],
      ['控制器端口', co.apiPort || '—'],
      ['配置目录', '~/.config/LoongClash'],
    ].map(([k, v]) => '<div class="env-item"><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>').join('');

    renderPerms(perms);
    renderGeo(await api('/api/geo'));
  } catch (e) { toast(e.message, true); }
}

function renderGeo(files) {
  $('#geo-list').innerHTML = (files || []).map((f) =>
    '<div class="env-item"><span>' + esc(f.name) + '</span><b>' +
    (f.exists ? bytes(f.size) : '<span class="muted">未下载</span>') + '</b></div>').join('');
}

$('#btn-geo').addEventListener('click', async () => {
  const b = $('#btn-geo');
  b.disabled = true; b.textContent = '下载中…';
  try {
    const r = await api('/api/geo/download', { method: 'POST', body: {} });
    toast(r.failed.length ? '部分文件下载失败：' + r.failed.map((f) => f.name).join(', ') : '数据下载完成',
      !!r.failed.length);
    renderGeo(r.files);
  } catch (e) { toast(e.message, true); }
  finally { b.disabled = false; b.textContent = '预下载数据'; }
});

function renderPerms(p) {
  $('#perm-list').innerHTML = (p.caps || []).map((c) =>
    '<div class="perm ' + (c.ok ? 'ok' : 'bad') + '"><span class="dot"></span><div><b>' +
    esc(c.name) + '</b><p>' + esc(c.detail) + '</p></div></div>').join('') +
    '<div class="perm ' + (p.sudo ? 'ok' : '') + '"><span class="dot"></span><div><b>免密码提权</b><p>' +
    (p.sudo ? '可用（sudoers 已授权 LoongClash）' : '不可用，TUN 模式将无法直接开启') + '</p></div></div>';
}

async function saveSettings() {
  const num = (v) => Number(v) || 0;
  const list = (v) => v.split(',').map((x) => x.trim()).filter(Boolean);
  const body = {
    mixedPort: num($('#set-port').value) || 7890,
    allowLan: $('#set-lan').checked,
    ipv6: $('#set-ipv6').checked,
    systemProxy: { enable: $('#set-sysproxy').checked, port: num($('#set-port').value) || 7890 },
    tun: {
      enable: $('#set-tun').checked,
      stack: $('#set-tun-stack').value,
      mtu: num($('#set-tun-mtu').value) || 9000,
    },
    dns: { nameserver: list($('#set-dns-ns').value), fallback: list($('#set-dns-fb').value) },
  };
  try {
    await api('/api/settings', { method: 'POST', body });
    $('#save-hint').textContent = '已保存 ' + new Date().toLocaleTimeString();
    toast('设置已保存');
    if (state.running) {
      await api('/api/core/reload', { method: 'POST' });
      toast('设置已保存，配置已热重载');
    }
    refreshOverview();
  } catch (e) { toast(e.message, true); }
}
$('#btn-save-settings').addEventListener('click', saveSettings);
$('#btn-recheck').addEventListener('click', loadSettings);

$('#btn-install-core').addEventListener('click', async () => {
  const path = $('#core-path').value.trim();
  if (!path) return toast('请填写内核文件路径', true);
  try {
    const r = await api('/api/core/install', { method: 'POST', body: { path } });
    toast('内核已安装：' + r.version);
    loadSettings(); refreshOverview();
  } catch (e) { toast(e.message, true); }
});

$('#btn-selftest').addEventListener('click', async () => {
  const btn = $('#btn-selftest');
  const box = $('#selftest-list');
  btn.disabled = true; btn.textContent = '检测中…';
  box.innerHTML = '<div class="empty" style="padding:12px">正在逐层检查…</div>';
  try {
    const r = await api('/api/self-test');
    box.innerHTML = r.steps.map((s) => (
      '<div class="perm ' + (s.ok ? 'ok' : 'bad') + '"><span class="dot"></span><div><b>' +
      esc(s.name) + '</b><p>' + esc(s.detail) +
      (s.hint ? '<br><span style="color:#e8a33d">→ ' + esc(s.hint) + '</span>' : '') +
      '</p></div></div>'
    )).join('');
    const bad = r.steps.filter((s) => !s.ok);
    toast(bad.length ? ('发现 ' + bad.length + ' 个问题，见下方提示') : '全部正常', !!bad.length);
  } catch (e) {
    box.innerHTML = '<div class="empty" style="padding:12px">' + esc(e.message) + '</div>';
    toast(e.message, true);
  } finally {
    btn.disabled = false; btn.textContent = '开始检测';
  }
});

/* ── 一键开启系统代理（顶部告警条）─────────── */
$('#btn-fix-sysproxy').addEventListener('click', async () => {
  const btn = $('#btn-fix-sysproxy');
  btn.disabled = true; btn.textContent = '设置中…';
  try {
    const r = await api('/api/system-proxy', { method: 'POST', body: { enable: true } });
    if (r && r.applied === false) {
      throw new Error('当前桌面环境（' + ((state.overview && state.overview.systemProxy || {}).desktop || '未知') +
        '）不支持自动设置，请手动把系统代理指向 127.0.0.1:' +
        ((state.overview && state.overview.settings && state.overview.settings.mixedPort) || 7890));
    }
    toast('系统代理已开启，现在打开浏览器试试');
    await Promise.all([refreshOverview(), loadSettings()]);
  } catch (e) {
    toast(e.message, true);
  } finally {
    btn.disabled = false; btn.textContent = '开启系统代理';
  }
});

/* ── 日志 ─────────────────────────────────── */
$('#btn-clear-log').addEventListener('click', () => { state.logs = []; $('#logbox').innerHTML = ''; });
$('#log-autoscroll').addEventListener('change', (e) => { state.autoScroll = e.target.checked; });

function appendLogs(lines) {
  if (!lines || !lines.length) return;
  const box = $('#logbox');
  const html = lines.map((l) => {
    const cls = / ERROR /.test(l) ? ' error' : / WARN /.test(l) ? ' warn' : '';
    const m = l.match(/^(\d\d:\d\d:\d\d)\s+(.*)$/);
    if (!m) return '<div class="logline' + cls + '">' + esc(l) + '</div>';
    return '<div class="logline' + cls + '"><span class="t">' + m[1] + '</span>  ' + esc(m[2]) + '</div>';
  }).join('');
  box.insertAdjacentHTML('beforeend', html);
  state.logs.push(...lines);
  while (box.childElementCount > 800) box.removeChild(box.firstChild);
  if (state.autoScroll) box.scrollTop = box.scrollHeight;
}

/* ── 轮询 ─────────────────────────────────── */
async function refreshOverview() {
  try {
    state.overview = await api('/api/overview');
    renderOverview();
    if (state.running) loadProxies();
    else { state.proxies = { groups: [], nodes: [] }; renderDashGroups(); }
  } catch (e) { /* 内核重启中静默 */ }
}

async function pullTraffic() {
  if (!state.running) { state.traffic = { up: 0, down: 0 }; return; }
  try {
    const c = await api('/api/connections');
    const seg = { up: Math.max(0, c.upload - (state.prevUp || 0)), down: Math.max(0, c.download - (state.prevDown || 0)) };
    state.prevUp = c.upload; state.prevDown = c.download;
    state.traffic = { up: seg.up, down: seg.down };
    state.sparkUp.push(seg.up); state.sparkDown.push(seg.down);
    if (state.sparkUp.length > 60) state.sparkUp.shift();
    if (state.sparkDown.length > 60) state.sparkDown.shift();
    $('#spark-up').textContent = rate(seg.up);
    $('#spark-down').textContent = rate(seg.down);
    $('#side-up').textContent = bytes(c.upload);
    $('#side-down').textContent = bytes(c.download);
    drawSpark();
  } catch (e) { /* ignore */ }
}

async function pullLogs() {
  try {
    const lines = await api('/api/logs?n=120');
    if (state.running) appendLogs(lines.filter((l) => !state.logs.includes(l)));
  } catch (e) { /* ignore */ }
}

async function boot() {
  try {
    const hs = await api('/api/handshake');
    $('#arch-label').textContent = 'v' + hs.version + ' · ' + hs.arch + (hs.isLoong ? ' · LoongArch' : '');
    $('#brand-sub').textContent = hs.isLoong ? '龙芯图形客户端' : '图形客户端';
  } catch (e) {
    $('#boot').innerHTML = '<div class="boot-logo">!</div><div class="boot-text">后端未响应：' + esc(e.message) + '</div>';
    return;
  }
  $('#boot').hidden = true;
  $('#app').hidden = false;
  await refreshOverview();
  drawSpark();
  setInterval(refreshOverview, 4000);
  setInterval(pullTraffic, 1000);
  setInterval(pullLogs, 2500);
  if (state.view === 'conns') setInterval(() => { if (state.view === 'conns') loadConns(); }, 3000);
}

window.addEventListener('resize', () => drawSpark());
boot();
