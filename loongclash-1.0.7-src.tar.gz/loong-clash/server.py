#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LoongClash - 龙芯 Loongnix 25 图形化 Clash 客户端
Copyright (c) 2026  LoongClash contributors
License: GPL-3.0

本文件是应用程序后端，只用 Python 3 标准库实现，不依赖任何第三方包，
因此在 loongarch64 / Debian 13 的纯净系统上可以直接运行。

架构：
    GTK3 外壳（gtk_shell.py，可选）
        └─ WebKit2 视图 / 浏览器  ──HTTP/JSON──▶  本文件（127.0.0.1 随机端口）
                                                   ├─ mihomo 内核子进程管理
                                                   ├─ 配置订阅解析 / 订阅更新
                                                   ├─ 节点延迟与出口测试
                                                   └─ TUN / 系统代理  权限处理
"""

import base64
import hashlib
import hmac
import json
import os
import platform
import re
import select
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_NAME = "LoongClash"
APP_VERSION = "1.0.7"
IS_LOONG = platform.machine() in ("loongarch64", "loong64")
UA = "clash.meta/%s" % APP_VERSION

LOG_RING = []
LOG_MAX = 600
LOG_LOCK = threading.Lock()

RESERVED_PORTS = set()

# 这些规则的目标会被直接解析成 IP 交给内核，若把内核自己的 API 域名也送去
# 解析，会造成「内核出口 → 域名 → 又回到内核」的环路。启动时用 hosts 钉住。
LOOPBACK_HOSTS = ("api.mihomo.local", "api.loongclash.local")

STATS = {"upload": 0, "download": 0, "conns": 0, "mem": 0, "uptime": 0}


# ─────────────────────────────────────────────────────────────
# 基础工具
# ─────────────────────────────────────────────────────────────
def log(msg, level="info"):
    line = "%s  %s  %s" % (time.strftime("%H:%M:%S"), level.upper().rjust(5), msg)
    with LOG_LOCK:
        LOG_RING.append(line)
        if len(LOG_RING) > LOG_MAX:
            del LOG_RING[: len(LOG_RING) - LOG_MAX]
    if os.environ.get("LOONGCLASH_DEBUG"):
        print(line, flush=True)


def log_tail(n=200):
    with LOG_LOCK:
        return list(LOG_RING[-n:])


def run(cmd, timeout=15, env=None):
    """执行命令并返回 (code, stdout, stderr)，任何异常都转成字符串。"""
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            env=env,
            universal_newlines=True,
        )
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except FileNotFoundError:
        return 127, "", "%s: 命令不存在" % cmd[0]
    except subprocess.TimeoutExpired:
        return 124, "", "命令执行超时"
    except Exception as exc:  # noqa: BLE001
        return 1, "", str(exc)


def is_root():
    return hasattr(os, "geteuid") and os.geteuid() == 0


def have(cmd):
    return shutil.which(cmd) is not None


def can_sudo():
    if is_root():
        return True
    if not have("sudo"):
        return False
    code, _, _ = run(["sudo", "-n", "true"], timeout=5)
    return code == 0


def free_port():
    while True:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        if port not in RESERVED_PORTS:
            RESERVED_PORTS.add(port)
            return port


def rand_secret(n=20):
    raw = os.urandom(24)
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(alphabet[b % len(alphabet)] for b in raw[:n])


def human_size(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.2f %s" % (n, unit))
        n /= 1024.0


def human_duration(sec):
    sec = int(sec or 0)
    d, sec = divmod(sec, 86400)
    h, sec = divmod(sec, 3600)
    m, sec = divmod(sec, 60)
    if d:
        return "%d 天 %d 小时" % (d, h)
    if h:
        return "%d 小时 %d 分" % (h, m)
    if m:
        return "%d 分 %d 秒" % (m, sec)
    return "%d 秒" % sec


def parse_proxy_url(url):
    """从订阅地址里取出可能自带的认证参数。"""
    p = urllib.parse.urlparse(url)
    headers = {}
    if p.username:
        token = "%s:%s" % (
            urllib.parse.unquote(p.username),
            urllib.parse.unquote(p.password or ""),
        )
        headers["Authorization"] = "Basic " + base64.b64encode(token.encode()).decode()
    clean = urllib.parse.urlunparse(p._replace(netloc=p.hostname + (":%d" % p.port if p.port else "")))
    return clean, headers


# ─────────────────────────────────────────────────────────────
# 极简 YAML 处理
#
# 不走 PyYAML 有两个原因：一是 Loongnix 的 python3 不带 PyYAML，装它要联网；
# 二是我们只需要"识别顶层键 + 替换顶层键"，缩进和注释保持原样，用户手写的
# 配置被程序改写的风险最小。
# ─────────────────────────────────────────────────────────────
def yaml_top_level_key(line):
    if not line or line[0] in " \t#-":
        return None
    m = re.match(r"^([A-Za-z0-9_\-\.'\"\u4e00-\u9fff]+)\s*:", line)
    if not m:
        return None
    return m.group(1).strip("'\"")


def yaml_top_level_keys(text):
    keys, seen = [], set()
    for line in text.splitlines():
        k = yaml_top_level_key(line)
        if k and k not in seen:
            seen.add(k)
            keys.append(k)
    return keys


def yaml_extract_block(text, key):
    """取出某个顶层键的整段内容（含该行）。"""
    out = []
    active = False
    for line in text.splitlines():
        if not active:
            if yaml_top_level_key(line) == key:
                active = True
                out.append(line)
            continue
        stripped = line.strip()
        # 遇到下一个顶层键就结束；空行和缩进行都属于当前块
        if stripped and not line[0].isspace() and not stripped.startswith("#"):
            break
        out.append(line)
    while out and not out[-1].strip():
        out.pop()
    return "\n".join(out)


def yaml_get_scalar(text, key):
    block = yaml_extract_block(text, key)
    if not block:
        return None
    rest = block.split(":", 1)[1].strip()
    if not rest or rest.startswith("#"):
        return None
    return rest.split(" #")[0].strip()


def yaml_remove_keys(text, keys):
    """删除指定的顶层标量键（含其整段块，防御订阅里写成多行的情况）。"""
    keys = set(keys)
    lines = text.splitlines()
    out, skip_until_indent = [], None
    for line in lines:
        if skip_until_indent is not None:
            # 正在跳过某个被删键的多行块
            if not line.strip() or (line[0].isspace() and len(line) - len(line.lstrip()) > skip_until_indent):
                continue
            skip_until_indent = None
        k = yaml_top_level_key(line)
        if k in keys:
            rest = line.split(":", 1)[1].strip() if ":" in line else ""
            if not rest or rest.startswith(("#", "|", ">")):
                # 块标量或空值：后续缩进行都属于它，一并删除
                skip_until_indent = 0
            continue
        out.append(line)
    while out and not out[-1].strip():
        out.pop()
    return "\n".join(out) + ("\n" if out else "")


def yaml_dedupe_top_keys(text):
    """去掉重复的顶层键（保留第一次出现的整块，删除后续同名块）。
    mihomo 的 YAML 解析器遇到重复键会直接 fatal，所以写盘前必须保证唯一。"""
    lines = text.splitlines()
    out, seen = [], set()
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        k = yaml_top_level_key(line)
        if k and k in seen:
            # 跳过这个重复键的整块（含缩进行的块标量与空行）
            i += 1
            while i < n:
                l2 = lines[i]
                s2 = l2.strip()
                if s2 and not l2[0].isspace() and not s2.startswith("#"):
                    break
                i += 1
            continue
        if k:
            seen.add(k)
        out.append(line)
        i += 1
    return "\n".join(out) + ("\n" if out else "")


def yaml_quote(value):
    return json.dumps(str(value), ensure_ascii=False)


def yaml_set_block(text, key, block_text):
    """替换（或追加）一个顶层键，其余内容原样保留。"""
    lines = text.splitlines()
    start = None
    for i, line in enumerate(lines):
        if yaml_top_level_key(line) == key:
            start = i
            break
    if start is None:
        body = text.rstrip() + "\n\n" + block_text.strip() + "\n"
        return body
    end = len(lines)
    for j in range(start + 1, len(lines)):
        stripped = lines[j].strip()
        if stripped and not lines[j][0].isspace() and not stripped.startswith("#"):
            end = j
            break
    new_lines = lines[:start] + block_text.rstrip().splitlines() + lines[end:]
    return "\n".join(new_lines) + "\n"


def yaml_uncomment(text, key):
    """把 `#key: value` 这种注释掉的顶层键还原成真实配置。"""
    out = []
    for line in text.splitlines():
        m = re.match(r"^#\s*([A-Za-z0-9_\-\.]+)\s*:\s*(.+)$", line)
        if m and m.group(1) == key:
            out.append("%s: %s" % (key, m.group(2).strip()))
        else:
            out.append(line)
    return "\n".join(out)


def split_cert_pair(pem):
    """从一段文本里拆出证书和私钥。"""
    cert = re.search(r"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----", pem, re.S)
    key = re.search(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", pem, re.S)
    return (cert.group(0) + "\n" if cert else ""), (key.group(0) + "\n" if key else "")


# ─────────────────────────────────────────────────────────────
# 配置策略：把任意订阅/配置文件加工成内核可用的配置
# ─────────────────────────────────────────────────────────────
def ensure_core_sections(conf, api_port, secret, controller="127.0.0.1:9090"):
    """注入外部控制、运行目录等内核必需项，返回 (新配置, 是否被加工过)。"""
    changed = []

    ext = (
        "# ── 以下由 LoongClash 自动维护 ──\n"
        "external-controller: %s\n"
        "secret: %s\n"
        "external-ui: ui\n" % (controller, yaml_quote(secret))
    )
    # external-controller / secret / external-ui 必须无条件覆盖：
    # 订阅里常自带 external-controller（还往往是 0.0.0.0:9090），
    # 如果不覆盖，内核实际监听的端口和我们记录的 ctl_port 不一致，
    # 界面就会报「无法连接内核 API: 连接被拒绝」
    conf = yaml_set_block(conf, "external-controller", ext)
    conf = yaml_set_block(conf, "secret", "secret: %s" % yaml_quote(secret))
    conf = yaml_set_block(conf, "external-ui", "external-ui: ui")
    changed.append("external-controller")

    if "mode" not in yaml_top_level_keys(conf):
        conf = yaml_set_block(conf, "mode", "mode: rule")
        changed.append("mode")

    if "log-level" not in yaml_top_level_keys(conf):
        conf = yaml_set_block(conf, "log-level", "log-level: info")
        changed.append("log-level")

    if "ipv6" not in yaml_top_level_keys(conf):
        conf = yaml_set_block(conf, "ipv6", "ipv6: false")
        changed.append("ipv6")

    profile = (
        "profile:\n"
        "  store-selected: true\n"
        "  store-fake-ip: true\n"
    )
    if "profile" not in yaml_top_level_keys(conf):
        conf = yaml_set_block(conf, "profile", profile)
        changed.append("profile")

    # 把内核自己的 API 域名钉死，避免内核在代理模式下解析自己造成环
    hosts_block = "\n".join('  "%s": 127.0.0.1' % h for h in LOOPBACK_HOSTS)
    hosts_block = "hosts:\n" + hosts_block
    existing = yaml_extract_block(conf, "hosts")
    if existing:
        conf = yaml_set_block(conf, "hosts", existing.rstrip() + "\n" + hosts_block.split("\n", 1)[1])
    else:
        conf = yaml_set_block(conf, "hosts", hosts_block)

    return conf, changed


def normalize_config(raw, app):
    """统一入口：把任意来源的文本变成可写入内核的 config.yaml。"""
    if isinstance(raw, (tuple, list)):
        # 防御：上游误传元组（如 (text, info)）时取第一个元素
        raw = raw[0] if raw else ""
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "replace")
    text = str(raw).replace("\r\n", "\n").strip() + "\n"
    keys = yaml_top_level_keys(text)
    if "proxies" not in keys and "proxy-providers" not in keys:
        raise ValueError("配置里没有 proxies 字段，看起来不是 Clash/mihomo 配置")
    if "proxy-groups" not in keys:
        # 单节点或极简配置，补一个最小可用的策略组
        text = yaml_set_block(
            text,
            "proxy-groups",
            "proxy-groups:\n"
            "  - name: PROXY\n"
            "    type: select\n"
            "    proxies:\n"
            '      - "DIRECT"\n',
        )
    if "rules" not in keys:
        text = yaml_set_block(
            text,
            "rules",
            "rules:\n"
            "  - MATCH,PROXY\n",
        )
    return text


# ─────────────────────────────────────────────────────────────
# 应用状态与内核管理
# ─────────────────────────────────────────────────────────────
class LoongClash(object):
    def __init__(self):
        self.home = os.path.expanduser("~/.config/LoongClash")
        self.core_dir = os.path.join(self.home, "core")
        self.profiles_dir = os.path.join(self.home, "profiles")
        self.runtime_dir = os.path.join(self.home, "runtime")
        self.ui_dir = os.path.join(self.home, "ui")
        self.log_file = os.path.join(self.home, "core.log")
        self.conf_path = os.path.join(self.runtime_dir, "config.yaml")
        self.settings_path = os.path.join(self.home, "settings.json")
        for d in (self.home, self.core_dir, self.profiles_dir, self.runtime_dir, self.ui_dir):
            os.makedirs(d, exist_ok=True)

        self.lock = threading.RLock()
        self.proc = None
        self.core_version = ""
        self.start_time = 0
        self.secret = rand_secret()
        self.api_port = 0
        self.ctl_port = 0
        self.last_error = ""
        self.settings = self._load_settings()
        self.profiles = self._load_profiles()
        self._core_log_pos = 0
        # 本次启动在日志文件中的起始行号，用于区分新旧会话输出
        self._session_log_start = 0
        self._last_api_ok = 0

    # ── 设置 ────────────────────────────────────────────────
    DEFAULT_SETTINGS = {
        "maxLogLines": 500,
        "allowLan": False,
        "ipv6": False,
        "tun": {"enable": False, "stack": "mixed", "dnsHijack": True, "mtu": 9000},
        # 默认开启：绝大多数用户启动后没连接，就是因为没人把流量交给代理
        "systemProxy": {"enable": True, "port": 7890},
        "dns": {"nameserver": ["223.5.5.5", "119.29.29.29"], "fallback": ["8.8.8.8", "1.1.1.1"]},
        "autoUpdateMinutes": 0,
        "theme": "dark",
        "customNodeName": False,
        "startAtBoot": False,
        "closeToTray": True,
        "mixedPort": 7890,
    }

    def _load_settings(self):
        data = {}
        try:
            with open(self.settings_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            pass
        except Exception as exc:  # noqa: BLE001
            log("读取设置失败：%s" % exc, "warn")
        merged = json.loads(json.dumps(self.DEFAULT_SETTINGS))
        for k, v in (data or {}).items():
            if isinstance(v, dict) and isinstance(merged.get(k), dict):
                merged[k].update(v)
            else:
                merged[k] = v
        return merged

    def save_settings(self, patch):
        with self.lock:
            for k, v in patch.items():
                if isinstance(v, dict) and isinstance(self.settings.get(k), dict):
                    self.settings[k].update(v)
                else:
                    self.settings[k] = v
            tmp = self.settings_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(self.settings, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, self.settings_path)
            self._apply_tun_port()
        return self.settings

    # ── 订阅（profile）───────────────────────────────────────
    def _profiles_index(self):
        return os.path.join(self.profiles_dir, "index.json")

    def _load_profiles(self):
        try:
            with open(self._profiles_index(), "r", encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            return {"items": [], "current": ""}
        except Exception as exc:  # noqa: BLE001
            log("读取订阅索引失败：%s" % exc, "warn")
            return {"items": [], "current": ""}

    def _save_profiles(self):
        tmp = self._profiles_index() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.profiles, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, self._profiles_index())

    def _profile_path(self, pid):
        return os.path.join(self.profiles_dir, "%s.yaml" % pid)

    def profile_add(self, name, url="", content="", kind="remote"):
        pid = "%s_%s" % (time.strftime("%Y%m%d%H%M%S"), rand_secret(4).lower())
        item = {
            "id": pid,
            "name": name or "未命名订阅",
            "url": url,
            "kind": kind,
            "created": int(time.time()),
            "updated": int(time.time()),
            "autoUpdate": True,
            "size": 0,
            "error": "",
        }
        with self.lock:
            self.profiles["items"].insert(0, item)
            self.profiles["current"] = pid
            self._save_profiles()
        if content:
            self._write_profile(pid, content)
            self.profile_stats(pid, content)
        return item

    def _write_profile(self, pid, text):
        path = self._profile_path(pid)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
        return path

    def profile_stats(self, pid, text=None):
        if text is None:
            try:
                with open(self._profile_path(pid), "r", encoding="utf-8") as fh:
                    text = fh.read()
            except OSError:
                return
        # 缩进可能是 2/4/6 空格，用 \s+ 而不是写死两个空格
        n_proxy = len(re.findall(r"^\s+-\s", yaml_extract_block(text, "proxies") or "", re.M))
        n_group = len(re.findall(r"^\s+-\s", yaml_extract_block(text, "proxy-groups") or "", re.M))
        n_rule = len(re.findall(r"^\s+-\s", yaml_extract_block(text, "rules") or "", re.M))
        with self.lock:
            for item in self.profiles["items"]:
                if item["id"] == pid:
                    item["size"] = len(text.encode("utf-8"))
                    item["proxies"] = n_proxy
                    item["groups"] = n_group
                    item["rules"] = n_rule
            self._save_profiles()
        return {"proxies": n_proxy, "groups": n_group, "rules": n_rule}

    def profile_delete(self, pid):
        with self.lock:
            self.profiles["items"] = [i for i in self.profiles["items"] if i["id"] != pid]
            if self.profiles["current"] == pid:
                self.profiles["current"] = self.profiles["items"][0]["id"] if self.profiles["items"] else ""
            self._save_profiles()
        try:
            os.remove(self._profile_path(pid))
        except OSError:
            pass
        return True

    def profile_read(self, pid):
        with open(self._profile_path(pid), "r", encoding="utf-8") as fh:
            return fh.read()

    def profile_update(self, pid):
        item = next((i for i in self.profiles["items"] if i["id"] == pid), None)
        if not item:
            raise ValueError("订阅不存在")
        if item["kind"] != "remote" or not item.get("url"):
            raise ValueError("本地配置文件无需更新")
        # http_fetch_text 返回 (文本, 附加信息) 元组，这里只取文本；
        # 并把建议文件名 / 流量信息回填到订阅卡片上
        try:
            text, info = http_fetch_text(item["url"], timeout=45)
        except Exception as exc:  # noqa: BLE001
            item["error"] = str(exc)[:200]
            self._save_profiles()
            raise ValueError("订阅下载失败：%s" % exc)
        if info.get("userinfo") and not item.get("userinfo"):
            item["userinfo"] = info["userinfo"]
        if info.get("filename") and not item.get("name"):
            item["name"] = info["filename"]
        text = normalize_config(text, self)
        self._write_profile(pid, text)
        self.profile_stats(pid, text)
        item["updated"] = int(time.time())
        item["error"] = ""
        self._save_profiles()
        log("订阅「%s」更新成功，%s" % (item["name"], human_size(len(text.encode('utf-8')))))
        return item

    # ── 内核 ────────────────────────────────────────────────
    def find_core(self):
        for name in ("mihomo", "clash-meta", "clash"):
            p = os.path.join(self.core_dir, name)
            if os.access(p, os.X_OK):
                return p
        for name in ("mihomo", "clash-meta", "clash"):
            w = shutil.which(name)
            if w:
                return w
        return ""

    def core_info(self):
        path = self.find_core()
        if not path:
            return {"path": "", "version": "", "found": False}
        if not self.core_version:
            code, out, _ = run([path, "-v"], timeout=20)
            self.core_version = out.splitlines()[0] if out else ""
        return {"path": path, "version": self.core_version, "found": True}

    def _apply_tun_port(self):
        tun = self.settings.get("tun", {})
        mixed = int(self.settings.get("mixedPort") or 7890)
        tun["port"] = mixed

    def build_config(self):
        """把当前订阅 + 设置合成为内核配置。"""
        cur = self.profiles.get("current")
        if not cur:
            raise ValueError("还没有选择订阅配置")
        path = self._profile_path(cur)
        if not os.path.exists(path):
            raise ValueError("订阅文件丢失，请重新导入")
        with open(path, "r", encoding="utf-8") as fh:
            conf = fh.read()

        conf = yaml_uncomment(conf, "mixed-port")

        # 订阅里可能自带 allow-lan / bind-address，先删掉旧值，
        # 否则下面注入时会造成顶层键重复，内核直接报
        # "mapping key already defined" 起不来
        conf = yaml_remove_keys(conf, ("allow-lan", "bind-address"))
        # 订阅里通常写着 port: 7890 / socks-port: 7891，而我们也用 7890 做
        # 混合端口。内核会先绑 port，再绑 mixed-port，于是自己和自己抢端口，
        # 日志里出现 "Mixed server error: address already in use"。
        # 统一改用 mixed-port，把独立的 port/socks-port/redir-port/tproxy 全部删掉。
        conf = yaml_remove_keys(conf, ("port", "socks-port", "redir-port",
                                       "tproxy-port", "mixed-port"))

        mixed = int(self.settings.get("mixedPort") or 7890)
        conf = yaml_set_block(
            conf,
            "mixed-port",
            "mixed-port: %d\nallow-lan: %s\nbind-address: '*'\n"
            % (mixed, "true" if self.settings.get("allowLan") else "false"),
        )
        # 不要占用 53 端口做 dns.listen，Ubuntu/Debian 的 systemd-resolved 会打架
        conf = yaml_set_block(
            conf,
            "ipv6",
            "ipv6: %s\n" % ("true" if self.settings.get("ipv6") else "false"),
        )

        dns = self.settings.get("dns", {})
        ns = dns.get("nameserver") or []
        fb = dns.get("fallback") or []
        dns_block = ["dns:", "  enable: true", "  ipv6: %s" % ("true" if self.settings.get("ipv6") else "false"),
                     "  enhanced-mode: fake-ip", "  fake-ip-range: 198.18.0.1/16",
                     '  fake-ip-filter:', '    - "*.lan"', '    - "*.local"', '    - "localhost.ptlogin2.qq.com"']
        if ns:
            dns_block.append("  nameserver:")
            dns_block += ['    - "%s"' % x for x in ns]
        if fb:
            dns_block.append("  fallback:")
            dns_block += ['    - "%s"' % x for x in fb]
        conf = yaml_set_block(conf, "dns", "\n".join(dns_block))

        tun = self.settings.get("tun", {})
        if tun.get("enable"):
            tun_block = "\n".join([
                "tun:",
                "  enable: true",
                "  stack: %s" % (tun.get("stack") or "mixed"),
                "  device: loongclash0",
                "  auto-route: true",
                "  auto-detect-interface: true",
                "  dns-hijack:",
                '    - "any:53"',
                "  mtu: %d" % int(tun.get("mtu") or 9000),
            ])
            conf = yaml_set_block(conf, "tun", tun_block)
        else:
            conf = yaml_set_block(conf, "tun", "tun:\n  enable: false")

        conf, _ = ensure_core_sections(conf, self.api_port, self.secret,
                                       "127.0.0.1:%d" % self.ctl_port)
        # 终极防线：无论订阅里写了什么、上面各步怎么拼接，
        # 交给内核前强制保证顶层键唯一（mihomo 对重复键直接 fatal）
        conf = yaml_dedupe_top_keys(conf)
        return conf

    def write_config(self):
        conf = self.build_config()
        tmp = self.conf_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(conf)
        os.replace(tmp, self.conf_path)  # 原子替换，内核热重载时不会读到半个文件
        return conf

    def _core_env(self):
        env = dict(os.environ)
        env["MIHOMO_HOME"] = self.runtime_dir
        env["SAFE_PATHS"] = "/usr/local/share:/usr/share"
        env["CLASH_HOME_DIR"] = self.runtime_dir
        # 内核日志中文化没必要，关掉避免多字节截断
        env.setdefault("LANG", "C.UTF-8")
        return env

    def _core_flags(self):
        flags = []
        if have("iw") or have("ip"):
            pass
        return flags

    def start_core(self):
        with self.lock:
            if self.proc and self.proc.poll() is None:
                return self.core_state()
            core = self.find_core()
            if not core:
                raise ValueError("未找到 mihomo 内核，请先在内核管理里安装")
            if not self.profiles.get("current"):
                raise ValueError("请先导入并选择一个订阅配置")

            # 清理上一轮遗留的内核进程：程序被强杀/崩溃后旧内核仍占着
            # mixed-port，会导致新内核起来但端口绑不上，界面表现为各种莫名报错
            self.kill_orphan_cores()

            self.api_port = free_port()
            self.ctl_port = free_port()
            self.write_config()
            self._install_ui()

            args = [
                core,
                "-d", self.runtime_dir,
                "-f", self.conf_path,
            ]
            need_sudo = bool(self.settings.get("tun", {}).get("enable")) or is_root() or \
                (os.geteuid() != 0 and not os.access(self.runtime_dir, os.W_OK))
            cmd = args
            if self.settings.get("tun", {}).get("enable") and not is_root():
                if not can_sudo():
                    raise ValueError("TUN 模式需要管理员权限，请先配置免密码 sudo 或在终端用 pkexec 启动")
                cmd = ["sudo", "-n"] + args
                need_sudo = True

            self._core_log_pos = 0
            # 日志文件每次启动都被重建，所以新会话从第 1 行开始
            self._session_log_start = 1
            lf = open(self.log_file, "w", encoding="utf-8")
            lf.write("=== %s 启动于 %s ===\n" % (APP_NAME, time.strftime("%Y-%m-%d %H:%M:%S")))
            lf.flush()
            log("启动内核：%s" % " ".join(cmd))
            # 必须走管道而不是直接写文件：Go 程序往文件写是 4KB 块缓冲，
            # 启动阶段的日志会迟迟不落盘，界面和排错都看不到。
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=self._core_env(),
                preexec_fn=os.setsid if os.name == "posix" else None,
                universal_newlines=True,
                bufsize=1,
            )
            self.start_time = time.time()
            self.last_error = ""
            threading.Thread(target=self._log_pump, daemon=True).start()

        # 最多等 30 秒：内核加载大 GeoIP/规则库时可能明显慢于 6 秒，
        # 过早返回会让界面立刻去连 API 并报「连接被拒绝」
        for _ in range(200):
            time.sleep(0.15)
            if self.proc.poll() is not None:
                break
            if self._api_ok():
                # API 通了还要确认代理端口真的绑上了：端口冲突时内核会
                # 继续跑但所有监听都失败，界面能连上却永远没流量
                time.sleep(0.4)
                tail = "\n".join(self.read_core_log(30, only_current=True))
                if "address already in use" in tail.lower():
                    m = re.search(r"listen tcp[^:]+:(\d+)", tail)
                    bad = m.group(1) if m else "端口"
                    self.last_error = (
                        "代理端口 %s 已被其他程序占用，内核虽然起来了但无法转发流量。"
                        "请在「设置」里换一个混合端口，或先关掉占用该端口的程序。" % bad)
                    log(self.last_error, "error")
                    # 关键：这个半残的内核必须杀掉，否则它会一直占着端口，
                    # 用户改完设置再启动还会撞同一个错
                    try:
                        p2 = self.proc
                        self.proc = None
                        if p2 and p2.poll() is None:
                            os.killpg(os.getpgid(p2.pid), signal.SIGTERM)
                    except Exception:  # noqa: BLE001
                        pass
                    raise ValueError(self.last_error)
                self._apply_system_proxy(True)
                log("内核启动成功，API 端口 %d" % self.ctl_port)
                return self.core_state()
        if self.proc.poll() is not None:
            # 内核退出时日志可能还在管道里，等它读完再下结论
            time.sleep(0.6)
            tail = "\n".join(self.read_core_log(60))
            self.last_error = self._guess_error(tail)
            log("内核启动失败：%s" % self.last_error, "error")
            raise ValueError(self.last_error)
        # 进程还活着但 API 一直没就绪：多半是 external-controller 冲突
        self.last_error = ("内核进程在运行但 API 一直没有就绪。可能是端口冲突或配置里"
                           " external-controller 被外部修改，请到「日志」页查看内核输出。")
        log(self.last_error, "warn")
        return self.core_state()

    def _guess_error(self, tail):
        low = tail.lower()
        if "can't download mmdb" in low or "can't initial geoip" in low:
            return ("内核启动失败：规则里用了 GEOIP/GEOSITE，但本地没有 geo 数据，内核去 GitHub "
                    "下载超时了。请在「设置 → 内核」里点「预下载 GeoIP 数据」，或把规则改成不走 GEOIP。")
        if "permission denied" in low:
            return "内核启动失败：权限不足。开启 TUN 模式需要 root 权限（见设置页的权限说明）。"
        if "address already in use" in low:
            m = re.search(r"listen tcp[^:]*:(\d+)", tail)
            port = m.group(1) if m else "端口"
            return "内核启动失败：端口 %s 已被占用，请在设置里换一个混合端口。" % port
        if "no such file" in low:
            return "内核启动失败：缺少依赖文件或内核路径错误。"
        lines = [l for l in tail.splitlines() if "level=error" in l or "level=fatal" in l
                 or "parse config error" in l.lower()]
        if lines:
            msg = re.sub(r"^time=\S+\s+level=\w+\s+msg=", "", lines[-1])
            return "内核启动失败：" + msg.strip('"')[:300]
        return "内核启动失败，请查看日志页的内核输出。"

    def _log_pump(self):
        """把内核输出逐行读出来，写进日志文件和内存环形缓冲。"""
        p = self.proc
        if p is None or p.stdout is None:
            return
        fh = None
        try:
            fh = open(self.log_file, "a", encoding="utf-8")
        except OSError:
            fh = None
        try:
            for raw in iter(p.stdout.readline, ""):
                line = raw.rstrip("\n")
                if not line.strip():
                    continue
                if fh:
                    try:
                        fh.write(line + "\n")
                        fh.flush()
                    except OSError:
                        pass
                low = line.lower()
                if "level=debug" in low or "level=trace" in low:
                    continue
                level = "error" if ("level=error" in low or "level=fatal" in low) else (
                    "warn" if "level=warn" in low else "info")
                m = re.search(r'msg="?([^"]*)"?$', line)
                text = m.group(1) if m else line
                log("[内核] " + text[:320], level)
        except Exception:  # noqa: BLE001
            pass
        finally:
            try:
                p.stdout.close()
            except Exception:  # noqa: BLE001
                pass
            if fh:
                try:
                    fh.close()
                except Exception:  # noqa: BLE001
                    pass

    def kill_orphan_cores(self):
        """杀掉所有指向本程序运行目录的 mihomo 残留进程。
        只认 runtime 目录作为判据，不会误杀用户自己跑的其他 clash 实例。"""
        try:
            import glob
            killed = 0
            for pid_dir in glob.glob("/proc/[0-9]*"):
                pid = os.path.basename(pid_dir)
                if pid == str(os.getpid()):
                    continue
                try:
                    with open(os.path.join(pid_dir, "cmdline"), "rb") as fh:
                        cmdline = fh.read().replace(b"\x00", b" ").decode("utf-8", "replace")
                except OSError:
                    continue
                if self.runtime_dir not in cmdline:
                    continue
                if not ("mihomo" in cmdline or "clash" in cmdline):
                    continue
                try:
                    os.kill(int(pid), signal.SIGTERM)
                    killed += 1
                except OSError:
                    pass
            if killed:
                log("清理了 %d 个遗留的内核进程" % killed, "warn")
                for _ in range(40):
                    time.sleep(0.1)
                    if not self._orphans_alive():
                        break
                if self._orphans_alive():
                    for pid_dir in glob.glob("/proc/[0-9]*"):
                        try:
                            with open(os.path.join(pid_dir, "cmdline"), "rb") as fh:
                                cmdline = fh.read().replace(b"\x00", b" ").decode("utf-8", "replace")
                            if self.runtime_dir in cmdline and ("mihomo" in cmdline or "clash" in cmdline):
                                os.kill(int(os.path.basename(pid_dir)), signal.SIGKILL)
                        except (OSError, ValueError):
                            pass
                    for _ in range(20):
                        time.sleep(0.1)
                        if not self._orphans_alive():
                            break
            # 再等一下端口真正释放（内核退出后 socket 可能短暂处于 TIME_WAIT）
            port = int(self.settings.get("mixedPort") or 7890)
            for _ in range(30):
                if not self._port_listening(port):
                    break
                time.sleep(0.1)
        except Exception as exc:  # noqa: BLE001
            log("清理遗留内核进程时出错：%s" % exc, "warn")

    def _port_listening(self, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return False
        except OSError:
            return True
        finally:
            s.close()

    def _orphans_alive(self):
        import glob
        for pid_dir in glob.glob("/proc/[0-9]*"):
            try:
                with open(os.path.join(pid_dir, "cmdline"), "rb") as fh:
                    cmdline = fh.read().replace(b"\x00", b" ").decode("utf-8", "replace")
                if self.runtime_dir in cmdline and ("mihomo" in cmdline or "clash" in cmdline):
                    return True
            except OSError:
                continue
        return False

    def stop_core(self):
        with self.lock:
            p, self.proc = self.proc, None
            if not p:
                return self.core_state()
            self._apply_system_proxy(False)
            try:
                if p.poll() is None:
                    try:
                        if os.name == "posix" and not self.settings.get("tun", {}).get("enable"):
                            os.killpg(os.getpgid(p.pid), signal.SIGTERM)
                        else:
                            subprocess.run(["sudo", "-n", "kill", "-TERM", str(p.pid)],
                                           timeout=6) if not is_root() else p.terminate()
                    except Exception:  # noqa: BLE001
                        p.terminate()
                    for _ in range(30):
                        if p.poll() is not None:
                            break
                        time.sleep(0.1)
                if p.poll() is None:
                    p.kill()
            except Exception as exc:  # noqa: BLE001
                log("停止内核时出错：%s" % exc, "warn")
            log("内核已停止")
        return self.core_state()

    def restart_core(self):
        self.stop_core()
        time.sleep(0.4)
        return self.start_core()

    def reload_config(self):
        self.write_config()
        self._install_ui()
        if self.proc and self.proc.poll() is None:
            self.api("PUT", "/configs?force=true", {"path": "", "payload": ""})
            log("配置已热重载")
        return self.core_state()

    def core_state(self):
        running = bool(self.proc and self.proc.poll() is None)
        return {
            "running": running,
            "pid": self.proc.pid if running else 0,
            "uptime": int(time.time() - self.start_time) if running else 0,
            "version": self.core_version,
            "path": self.find_core(),
            "apiPort": self.ctl_port,
            "mixedPort": int(self.settings.get("mixedPort") or 7890),
            "error": self.last_error,
        }

    def read_core_log(self, n=200, only_current=False):
        """only_current=True 时只返回本次启动之后的日志，
        避免用上一轮的旧错误（如上次的端口冲突）误判本次启动结果。"""
        try:
            with open(self.log_file, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.read().splitlines()
        except OSError:
            return []
        if only_current:
            start = self._session_log_start
            if start > 0:
                lines = lines[start:]
        return lines[-n:]

    # ── 内核 API ────────────────────────────────────────────
    def _api_request(self, method, path, body=None, timeout=8):
        if not self.ctl_port:
            raise ValueError("内核未运行")
        url = "http://127.0.0.1:%d%s" % (self.ctl_port, path)
        data = None
        headers = {"Authorization": "Bearer %s" % self.secret}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:300]
            raise ValueError("内核返回 %s：%s" % (exc.code, detail))
        except (urllib.error.URLError, socket.timeout, ConnectionError) as exc:
            raise ValueError("无法连接内核 API：%s" % exc)
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            return {}

    def api(self, method, path, body=None, timeout=8):
        return self._api_request(method, path, body, timeout)

    def _api_ok(self):
        try:
            self._api_request("GET", "/version", timeout=2)
            self._last_api_ok = time.time()
            return True
        except Exception:  # noqa: BLE001
            return False

    # ── UI 静态资源 ─────────────────────────────────────────
    def ui_source(self):
        here = os.path.dirname(os.path.abspath(__file__))
        for cand in (os.path.join(here, "ui"), os.path.join(here, "..", "ui"),
                     "/usr/share/loongclash/ui"):
            if os.path.isfile(os.path.join(cand, "index.html")):
                return os.path.abspath(cand)
        return ""

    def _install_ui(self):
        """把内置界面复制到内核的 external-ui 目录。"""
        src = self.ui_source()
        if not src:
            return
        dst = os.path.join(self.runtime_dir, "ui")
        os.makedirs(dst, exist_ok=True)
        for name in os.listdir(src):
            s = os.path.join(src, name)
            d = os.path.join(dst, name)
            if os.path.isfile(s):
                shutil.copyfile(s, d)

    # ── 系统代理 ────────────────────────────────────────────
    def _gsettings(self, schema, key, value):
        """写 dconf。注意：gsettings 在 dconf 不可用（没有 D-Bus 会话）时
        退出码依然是 0，只在 stderr 里抱怨，所以必须回读校验，
        否则会「假成功」——界面显示已开启，实际一点没生效。"""
        code, _out, err = run(["gsettings", "set", schema, key, value], timeout=6)
        if code != 0:
            return False
        got_code, got, _ = run(["gsettings", "get", schema, key], timeout=6)
        if got_code != 0:
            return False
        norm = lambda s: (s or "").strip().strip("'").lower()
        if norm(got) != norm(value):
            if err:
                log("gsettings 写入未生效：%s" % err.strip().splitlines()[-1][:160], "warn")
            return False
        return True

    def detect_desktop(self):
        de = (os.environ.get("XDG_CURRENT_DESKTOP") or "").lower()
        if not de:
            code, out, _ = run(["bash", "-lc", 'echo "$XDG_CURRENT_DESKTOP"'], timeout=5)
            de = (out or "").lower()
        if "kde" in de or "plasma" in de:
            return "kde"
        if "xfce" in de:
            return "xfce"
        if "gnome" in de or "unity" in de or "ubuntu" in de or "pantheon" in de:
            return "gnome"
        if have("gsettings"):
            return "gnome"
        return "unknown"

    def system_proxy_state(self):
        de = self.detect_desktop()
        port = int(self.settings.get("systemProxy", {}).get("port") or self.settings.get("mixedPort") or 7890)
        st = {"desktop": de, "enabled": False, "port": port, "mode": "manual", "supported": True}
        if de in ("gnome", "xfce"):
            code, out, _ = run(["gsettings", "get", "org.gnome.system.proxy", "mode"], timeout=6)
            st["enabled"] = (out or "").strip().strip("'") == "manual"
            code, host, _ = run(["gsettings", "get", "org.gnome.system.proxy.http", "host"], timeout=6)
            if st["enabled"] and (host or "").strip().strip("'"):
                st["host"] = host.strip().strip("'")
        elif de == "kde":
            code, out, _ = run(["kwriteconfig6", "--file", "kioslaverc", "--group", "Proxy Settings",
                                "--key", "ProxyType", "--stdout"] if False else
                               ["bash", "-lc", "kreadconfig6 --file kioslaverc --group 'Proxy Settings' --key ProxyType 2>/dev/null "
                                "|| kreadconfig5 --file kioslaverc --group 'Proxy Settings' --key ProxyType"], timeout=8)
            st["enabled"] = (out or "").strip() == "1"
        else:
            st["supported"] = de != "unknown"
        st["env"] = {k: os.environ.get(k, "") for k in
                     ("http_proxy", "https_proxy", "all_proxy")}
        return st

    def _apply_system_proxy(self, enable):
        if not self.settings.get("systemProxy", {}).get("enable"):
            return False
        return self.set_system_proxy(enable, quiet=True)

    def set_system_proxy(self, enable, quiet=False):
        port = int(self.settings.get("systemProxy", {}).get("port") or
                   self.settings.get("mixedPort") or 7890)
        de = self.detect_desktop()
        ok = True
        if de in ("gnome", "xfce"):
            if enable:
                # 顺序要紧：先写 host/port 再翻 mode，避免出现「已启用但端口空」的瞬间
                ok = self._gsettings("org.gnome.system.proxy", "ignore-hosts",
                                     "['localhost','127.0.0.0/8','::1','*.local',"
                                     "'10.0.0.0/8','172.16.0.0/12','192.168.0.0/16']") and ok
                for scheme in ("http", "https", "ftp", "socks"):
                    ok = self._gsettings("org.gnome.system.proxy.%s" % scheme, "host",
                                         "127.0.0.1") and ok
                    ok = self._gsettings("org.gnome.system.proxy.%s" % scheme, "port",
                                         str(port)) and ok
                ok = self._gsettings("org.gnome.system.proxy", "mode", "manual") and ok
            else:
                ok = self._gsettings("org.gnome.system.proxy", "mode", "none")
        elif de == "kde":
            def kw(key, val):
                exe = "kwriteconfig6" if have("kwriteconfig6") else "kwriteconfig5"
                if not have(exe):
                    return False
                code, _o, _e = run([exe, "--file", "kioslaverc", "--group", "Proxy Settings",
                                    "--key", key, val], timeout=8)
                return code == 0
            if enable:
                ok = kw("ProxyType", "1") and ok
                ok = kw("httpProxy", "http://127.0.0.1:%d" % port) and ok
                ok = kw("httpsProxy", "http://127.0.0.1:%d" % port) and ok
                ok = kw("socksProxy", "socks://127.0.0.1:%d" % port) and ok
                ok = kw("NoProxyFor",
                        "localhost,127.0.0.1,::1,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,*.local") and ok
            else:
                ok = kw("ProxyType", "0")
        else:
            if not quiet:
                log("未识别的桌面环境（%s），无法自动设置系统代理" % de, "warn")
            return False
        # 写完后以「实际状态」为准，不以命令返回值自我安慰
        if enable:
            state = self.system_proxy_state()
            if not state.get("enabled"):
                ok = False
        if not quiet:
            if ok:
                log("系统代理已%s（%s，127.0.0.1:%d）" % ("开启" if enable else "关闭", de, port))
            else:
                log("系统代理设置失败（%s）。若使用 GNOME 系，通常是缺少 D-Bus 会话；"
                    "可手动把系统代理设为 127.0.0.1:%d" % (de, port), "warn")
        return ok

    def self_test(self):
        """逐层体检：端口是否在听、代理能否转发、规则命中什么、
        系统代理是否指向本端口。用来回答「启动了但没连接」这类问题。"""
        steps = []
        port = int(self.settings.get("mixedPort") or 7890)

        # 1. 端口监听
        listening = False
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=2)
            s.close()
            listening = True
        except OSError as exc:
            steps.append({"ok": False, "name": "代理端口 %d" % port,
                          "detail": "无法连接：%s" % exc,
                          "hint": "内核未运行或端口被改过"})
        if listening:
            steps.append({"ok": True, "name": "代理端口 %d" % port,
                          "detail": "正在监听，可以接受连接"})

        # 2. 通过代理实际发一次请求（走内核自身的规则链）
        if listening:
            try:
                proxy = "http://127.0.0.1:%d" % port
                opener = urllib.request.build_opener(
                    urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
                req = urllib.request.Request("http://www.gstatic.com/generate_204",
                                             headers={"User-Agent": UA})
                with opener.open(req, timeout=12) as resp:
                    code = resp.status
                ok = code in (204, 200)
                steps.append({"ok": ok, "name": "代理链路测试",
                              "detail": "经代理访问测试地址返回 %s" % code,
                              "hint": "" if ok else "节点不通，检查节点延迟或换一个节点"})
            except Exception as exc:  # noqa: BLE001
                steps.append({"ok": False, "name": "代理链路测试",
                              "detail": "经代理访问失败：%s" % str(exc)[:160],
                              "hint": "当前选中的节点不可用，到「节点」页测延迟并切换"})

        # 3. 系统代理是否指向本端口
        sp = self.system_proxy_state()
        if sp.get("enabled") and sp.get("host") in ("127.0.0.1", "localhost"):
            steps.append({"ok": True, "name": "系统代理",
                          "detail": "已指向 %s:%s" % (sp.get("host"), sp.get("port"))})
        elif sp.get("enabled"):
            steps.append({"ok": False, "name": "系统代理",
                          "detail": "已开启但指向 %s:%s" % (sp.get("host"), sp.get("port")),
                          "hint": "与本程序端口不一致，请在本程序里重新开关一次系统代理"})
        else:
            steps.append({"ok": False, "name": "系统代理",
                          "detail": "未开启（桌面：%s）" % sp.get("desktop", "未知"),
                          "hint": "如果浏览器没手动设代理，就不会有任何连接。"
                                  "在「设置」里打开「系统代理」，或手动把浏览器代理设为 "
                                  "127.0.0.1:%d" % port})

        # 4. 当前连接数
        conns = 0
        try:
            d = self.api("GET", "/connections", timeout=4)
            conns = len(d.get("connections") or [])
        except Exception:  # noqa: BLE001
            pass
        steps.append({"ok": conns > 0, "name": "活动连接数",
                      "detail": "当前 %d 条" % conns,
                      "hint": "" if conns else "有流量经过时这里的数字才会增长"})

        # 把「系统代理没开」这种隐形问题摆到界面上，而不是让用户对着
        # 0 条连接发呆
        warn = ""
        if steps and not any(s["name"] == "系统代理" and s["ok"] for s in steps):
            sp_state = self.system_proxy_state()
            if not sp_state.get("enabled"):
                warn = ("代理已运行，但系统代理未开启：浏览器等程序不会自动走代理。"
                        "请到「设置」打开「系统代理」，或手动把应用代理设为 127.0.0.1:%d" % port)

        return {"steps": steps, "port": port,
                "desktop": sp.get("desktop"), "count": conns, "warning": warn}

    # ── 权限自检 ────────────────────────────────────────────
    def permission_report(self):
        core = self.find_core()
        caps = []
        caps.append({
            "key": "core",
            "name": "mihomo 内核",
            "ok": bool(core),
            "detail": core or "未安装",
        })
        caps.append({
            "key": "port",
            "name": "监听 7890 等高位端口",
            "ok": True,
            "detail": "普通用户即可绑定 1024 以上端口",
        })
        caps.append({
            "key": "sysproxy",
            "name": "修改桌面代理设置",
            "ok": have("gsettings") or have("kwriteconfig6") or have("kwriteconfig5"),
            "detail": "通过 gsettings / kde config 生效，无需 root",
        })
        v = self.tun_capability()
        caps.append({
            "key": "tun",
            "name": "TUN 透明代理",
            "ok": v["ok"],
            "detail": v["detail"],
        })
        return {"isRoot": is_root(), "sudo": can_sudo(), "caps": caps, "arch": platform.machine()}

    def tun_capability(self):
        if os.environ.get("LOONGCLASH_FORCE_TUN"):
            return {"ok": True, "detail": "已强制允许（调试模式）"}
        if platform.machine() not in ("loongarch64", "loong64") and not IS_LOONG and os.name == "posix":
            # 非龙芯平台上仅做提示，不阻止
            pass
        if not os.path.exists("/dev/net/tun"):
            return {"ok": False, "detail": "系统没有 /dev/net/tun 设备节点。/boot 内核未加载 tun 模块时 TUN 不可用，"
                                           "可执行 sudo modprobe tun 后重试。"}
        if is_root():
            return {"ok": True, "detail": "当前以 root 运行，可直接创建 TUN"}
        if can_sudo():
            return {"ok": True, "detail": "可通过免密码 sudo 提权创建 TUN"}
        return {"ok": False, "detail": "TUN 需要 root。请用 sudo ./start.sh 启动，或执行 packaging/ 目录里的一键授权脚本。"}

    # ── 订阅文件下载 ────────────────────────────────────────
    def core_install(self, path):
        with open(path, "rb") as fh:
            head = fh.read(4)
        magic = {b"\x7fELF": "ELF 可执行文件", b"PK\x03\x04": "压缩包"}
        kind = magic.get(head, "未知格式")
        if kind != "ELF 可执行文件":
            raise ValueError("不是 ELF 可执行文件（检测到 %s）" % kind)
        os.makedirs(self.core_dir, exist_ok=True)
        dst = os.path.join(self.core_dir, "mihomo")
        shutil.copyfile(path, dst)
        os.chmod(dst, 0o755)
        self.core_version = ""
        code, out, err = run([dst, "-v"], timeout=25)
        if code != 0:
            raise ValueError("内核无法执行：%s" % (err or out or "未知错误"))
        self.core_version = out.splitlines()[0] if out else ""
        log("内核已安装：%s" % self.core_version)
        return {"version": self.core_version, "path": dst}

    # ── geo 数据 ────────────────────────────────────────────
    GEO_FILES = {
        "geoip.metadb": "meta-rules-dat/releases/download/latest/geoip.metadb",
        "GeoSite.dat": "meta-rules-dat/releases/download/latest/GeoSite.dat",
        "geosite.dat": "meta-rules-dat/releases/download/latest/geosite.dat",
        "ASN.mmdb": "meta-rules-dat/releases/download/latest/ASN.mmdb",
    }
    GEO_MIRRORS = [
        "https://ghfast.top/https://github.com/MetaCubeX/{path}",
        "https://gh-proxy.com/https://github.com/MetaCubeX/{path}",
        "https://github.com/MetaCubeX/{path}",
    ]

    def geo_state(self):
        out = []
        for name in ("geoip.metadb", "GeoSite.dat", "geosite.dat", "ASN.mmdb"):
            p = os.path.join(self.runtime_dir, name)
            out.append({
                "name": name,
                "exists": os.path.exists(p),
                "size": os.path.getsize(p) if os.path.exists(p) else 0,
            })
        return out

    def geo_download(self, which=None):
        """预下载 GEOIP/GEOSITE 数据。内核自己下会卡在 GitHub 且只等 90 秒，
        在国内网络下几乎必然失败，所以由这里带镜像按顺序重试。"""
        targets = [which] if which else ["geoip.metadb", "GeoSite.dat"]
        done, failed = [], []
        for name in targets:
            rel = self.GEO_FILES.get(name)
            if not rel:
                failed.append({"name": name, "error": "未知文件"})
                continue
            ok = False
            for tpl in self.GEO_MIRRORS:
                url = tpl.format(path=rel)
                try:
                    log("开始下载 %s ← %s" % (name, url.split("//")[1][:40]))
                    req = urllib.request.Request(url, headers={"User-Agent": UA})
                    ctx = ssl.create_default_context()
                    with urllib.request.urlopen(req, timeout=120, context=ctx) as resp:
                        data = resp.read()
                    if len(data) < 100000:
                        raise ValueError("文件过小，可能是错误页")
                    tmp = os.path.join(self.runtime_dir, name + ".tmp")
                    with open(tmp, "wb") as fh:
                        fh.write(data)
                    os.replace(tmp, os.path.join(self.runtime_dir, name))
                    log("%s 下载完成，%s" % (name, human_size(len(data))))
                    done.append({"name": name, "size": len(data)})
                    ok = True
                    break
                except Exception as exc:  # noqa: BLE001
                    log("%s 下载失败：%s" % (name, exc), "warn")
            if not ok:
                failed.append({"name": name, "error": "所有镜像都失败，请检查网络后重试"})
        return {"done": done, "failed": failed, "files": self.geo_state()}


def http_fetch_text(url, timeout=30, extra_headers=None):
    clean, headers = parse_proxy_url(url)
    headers.setdefault("User-Agent", UA)
    headers.setdefault("Accept", "*/*")
    for k, v in (extra_headers or {}).items():
        headers[k] = v
    req = urllib.request.Request(clean, headers=headers)
    ctx = None
    if clean.lower().startswith("https"):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE  # 机场订阅常见自签证书，不校验证书链
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
        raw = resp.read()
        name = resp.headers.get("Content-Disposition", "")
        info = resp.headers.get("subscription-userinfo", "")
    text = None
    for enc in ("utf-8", "gb18030", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    m = re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)", name)
    suggested = urllib.parse.unquote(m.group(1)) if m else ""
    return text or "", {"filename": suggested, "userinfo": info}


app = LoongClash()


# ─────────────────────────────────────────────────────────────
# HTTP 服务
# ─────────────────────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    server_version = "%s/%s" % (APP_NAME, APP_VERSION)
    protocol_version = "HTTP/1.1"
    token = ""

    def log_message(self, fmt, *args):  # 静默默认日志
        pass

    # ── 响应助手 ────────────────────────────────────────────
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, data, code=200):
        self._send(code, {"ok": True, "data": data})

    def _err(self, msg, code=400):
        if isinstance(msg, Exception):
            msg = str(msg) or msg.__class__.__name__
        self._send(code, {"ok": False, "error": msg})

    def _read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            raise ValueError("请求体不是合法 JSON")

    def _authorized(self):
        if not self.token:
            return True
        if self.client_address[0] not in ("127.0.0.1", "::1"):
            return False
        got = self.headers.get("X-LoongClash-Token", "")
        return hmac.compare_digest(got, self.token)

    # ── 路由 ────────────────────────────────────────────────
    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")

    def do_PUT(self):
        self._route("PUT")

    def do_DELETE(self):
        self._route("DELETE")

    def _route(self, method):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if not path.startswith("/api/"):
            return self._static(path)

        if path != "/api/handshake" and not self._authorized():
            return self._err("会话校验失败，请刷新界面", 403)

        try:
            body = self._read_json() if method in ("POST", "PUT", "DELETE") else {}
            return self._api(method, path, query, body)
        except ValueError as exc:
            return self._err(exc, 400)
        except Exception as exc:  # noqa: BLE001
            log("API 异常 %s %s：%s" % (method, path, exc), "error")
            if os.environ.get("LOONGCLASH_DEBUG"):
                traceback.print_exc()
            return self._err("内部错误：%s" % exc, 500)

    def _api(self, method, path, q, body):
        # --- 握手 ---
        if path == "/api/handshake":
            return self._json({"app": APP_NAME, "version": APP_VERSION,
                               "arch": platform.machine(), "isLoong": IS_LOONG})

        # --- 总览 ---
        if path == "/api/overview":
            return self._json(self._overview())

        if path == "/api/core" and method == "GET":
            return self._json(dict(app.core_info(), **app.core_state()))

        if path == "/api/core/start" and method == "POST":
            return self._json(app.start_core())
        if path == "/api/core/stop" and method == "POST":
            return self._json(app.stop_core())
        if path == "/api/core/restart" and method == "POST":
            return self._json(app.restart_core())
        if path == "/api/core/reload" and method == "POST":
            return self._json(app.reload_config())
        if path == "/api/core/install" and method == "POST":
            p = body.get("path") or ""
            if not os.path.isfile(p):
                raise ValueError("文件不存在：%s" % p)
            return self._json(app.core_install(p))
        if path == "/api/geo" and method == "GET":
            return self._json(app.geo_state())
        if path == "/api/geo/download" and method == "POST":
            return self._json(app.geo_download(body.get("name")))

        # --- 内核 API 转发 ---
        if path == "/api/proxies":
            return self._json(self._proxies())
        if path == "/api/proxy/select" and method == "PUT":
            group = body.get("group")
            name = body.get("name")
            if not group or not name:
                raise ValueError("缺少参数")
            app.api("PUT", "/proxies/%s" % urllib.parse.quote(group, safe=""),
                    {"name": name})
            return self._json({"group": group, "now": name})
        if path == "/api/proxy/delay" and method == "POST":
            return self._json(self._delay(body))
        if path == "/api/connections":
            return self._json(self._connections())
        if path == "/api/connections/close" and method == "POST":
            cid = body.get("id")
            if cid:
                app.api("DELETE", "/connections/%s" % cid)
            else:
                app.api("DELETE", "/connections")
            return self._json({"closed": cid or "all"})
        if path == "/api/traffic":
            return self._json(self._traffic())
        if path == "/api/logs":
            return self._json(app.read_core_log(int(q.get("n", ["120"])[0])))
        if path == "/api/rules":
            return self._json(self._rules())
        if path == "/api/configs":
            if method == "GET":
                return self._json(app.api("GET", "/configs"))
            app.api("PATCH", "/configs", body)
            return self._json(app.api("GET", "/configs"))
        if path == "/api/mode" and method == "PUT":
            mode = body.get("mode")
            if mode not in ("rule", "global", "direct"):
                raise ValueError("模式只能是 rule/global/direct")
            app.api("PATCH", "/configs", {"mode": mode})
            return self._json({"mode": mode})

        # --- 订阅 ---
        if path == "/api/profiles" and method == "GET":
            return self._json(app.profiles)
        if path == "/api/profile/add" and method == "POST":
            return self._json(self._profile_add(body))
        if path == "/api/profile/update" and method == "POST":
            return self._json(app.profile_update(body.get("id")))
        if path == "/api/profile/select" and method == "POST":
            pid = body.get("id")
            if not any(i["id"] == pid for i in app.profiles["items"]):
                raise ValueError("订阅不存在")
            app.profiles["current"] = pid
            app._save_profiles()
            if app.core_state()["running"]:
                return self._json(app.restart_core())
            return self._json({"current": pid})
        if path == "/api/profile/delete" and method == "POST":
            return self._json({"deleted": app.profile_delete(body.get("id"))})
        if path == "/api/profile/content" and method == "GET":
            return self._json({"content": app.profile_read(q.get("id", [""])[0])})
        if path == "/api/profile/save" and method == "POST":
            pid = body.get("id")
            text = normalize_config(body.get("content") or "", app)
            app._write_profile(pid, text)
            app.profile_stats(pid, text)
            if app.core_state()["running"]:
                return self._json(app.reload_config())
            return self._json({"saved": True})
        if path == "/api/settings" and method == "GET":
            return self._json(app.settings)
        if path == "/api/settings" and method == "POST":
            return self._json(app.save_settings(body))
        if path == "/api/permissions":
            return self._json(app.permission_report())
        if path == "/api/self-test":
            return self._json(app.self_test())
        if path == "/api/system-proxy" and method == "GET":
            return self._json(app.system_proxy_state())
        if path == "/api/system-proxy" and method == "POST":
            ok = app.set_system_proxy(bool(body.get("enable")))
            return self._json({"enabled": bool(body.get("enable")), "applied": ok})
        if path == "/api/pick-file":
            return self._json({"path": pick_local_file()})

        raise ValueError("未知接口：%s" % path)

    # ── 业务组装 ────────────────────────────────────────────
    def _overview(self):
        st = app.core_state()
        out = {
            "core": st,
            "settings": app.settings,
            "profiles": {k: app.profiles[k] for k in ("current",)},
            "profileCount": len(app.profiles["items"]),
            "permissions": app.permission_report(),
            "systemProxy": app.system_proxy_state(),
            "traffic": dict(STATS),
            "mode": "rule",
            "warn": "",
        }
        if st["running"]:
            try:
                conf = app.api("GET", "/configs")
                out["mode"] = conf.get("mode", "rule")
                out["mixedPort"] = conf.get("mixed-port")
                # 运行中但系统代理没开：界面顶部直接提示
                sp_now = out["systemProxy"]
                if not sp_now.get("enabled"):
                    out["warn"] = ("代理已运行，但系统代理未开启，浏览器不会自动使用代理。"
                                   "请在「设置」里打开「系统代理」，或手动设置代理为 127.0.0.1:%s"
                                   % (conf.get("mixed-port") or app.settings.get("mixedPort")))
            except ValueError as exc:
                out["apiError"] = str(exc)
        return out

    def _proxies(self):
        data = app.api("GET", "/proxies")
        proxies = data.get("proxies", {})
        groups = []
        for name, p in proxies.items():
            if p.get("type") in ("Selector", "URLTest", "Fallback", "LoadBalance", "Relay"):
                groups.append({
                    "name": name,
                    "type": p.get("type"),
                    "now": p.get("now"),
                    "all": p.get("all", []),
                    "history": p.get("history", []),
                })
        nodes = []
        for name, p in proxies.items():
            if p.get("type") in ("Selector", "URLTest", "Fallback", "LoadBalance", "Relay", "Direct", "Reject",
                                 "Compatible", "Pass", "RejectDrop"):
                continue
            hist = p.get("history") or []
            delay = hist[-1].get("delay", 0) if hist else 0
            nodes.append({"name": name, "type": p.get("type"), "delay": delay,
                          "udp": p.get("udp", False)})
        return {"groups": groups, "nodes": nodes}

    def _delay(self, body):
        group = body.get("group")
        names = body.get("names")
        url = body.get("url") or "http://www.gstatic.com/generate_204"
        timeout = int(body.get("timeout") or 5000)
        results = {}

        def one(name):
            try:
                q = urllib.parse.urlencode({"url": url, "timeout": timeout})
                path = "/proxies/%s/delay?%s" % (urllib.parse.quote(name, safe=""), q)
                r = app.api("GET", path, timeout=max(6, timeout / 1000 + 3))
                results[name] = int(r.get("delay", 0))
            except Exception as exc:  # noqa: BLE001
                results[name] = {"error": str(exc)[:120]}

        if group and not names:
            # 整组测速：内核的 /group/{name}/delay 会并发测组内全部节点，
            # 返回 {节点名: 延迟} 映射。之前这里压根没发请求，
            # 导致界面永远显示「可用节点 0 个」。
            try:
                q = urllib.parse.urlencode({"url": url, "timeout": timeout})
                path = "/group/%s/delay?%s" % (urllib.parse.quote(group, safe=""), q)
                m = app.api("GET", path, timeout=max(10, timeout / 1000 + 8))
                for k, v in m.items():
                    try:
                        results[k] = int(v)
                    except (TypeError, ValueError):
                        results[k] = {"error": str(v)[:120]}
            except Exception as exc:  # noqa: BLE001
                raise ValueError("测速失败：%s" % str(exc)[:160])
            return {"url": url, "results": results}

        if names:
            threads = []
            for n in names[:120]:
                t = threading.Thread(target=one, args=(n,), daemon=True)
                t.start()
                threads.append(t)
            for t in threads:
                t.join(timeout=(timeout / 1000) + 8)
        return {"url": url, "results": results}

    def _connections(self):
        data = app.api("GET", "/connections")
        conns = data.get("connections") or []
        up = sum(c.get("upload", 0) for c in conns)
        down = sum(c.get("download", 0) for c in conns)
        STATS.update({"upload": up, "download": down, "conns": len(conns),
                      "mem": data.get("memory", 0)})
        out = []
        for c in conns[:300]:
            meta = c.get("metadata", {})
            out.append({
                "id": c.get("id"),
                "host": meta.get("host") or meta.get("destinationIP", ""),
                "dest": "%s:%s" % (meta.get("destinationIP", ""), meta.get("destinationPort", "")),
                "network": (c.get("chains") or ["-"]),
                "rule": c.get("rule", ""),
                "rulePayload": c.get("rulePayload", ""),
                "upload": c.get("upload", 0),
                "download": c.get("download", 0),
                "start": c.get("start", ""),
                "process": meta.get("processPath", "") or meta.get("sourceIP", ""),
            })
        return {"items": out, "total": len(conns), "upload": up, "download": down}

    def _traffic(self):
        try:
            up = app.api("GET", "/traffic/upload/total", timeout=3)
            down = app.api("GET", "/traffic/download/total", timeout=3)
        except ValueError:
            up = down = {}
        return {
            "uploadTotal": up.get("bytes", 0) if isinstance(up, dict) else 0,
            "downloadTotal": down.get("bytes", 0) if isinstance(down, dict) else 0,
            "uploadLabel": human_size((up or {}).get("bytes", 0) if isinstance(up, dict) else 0),
            "downloadLabel": human_size((down or {}).get("bytes", 0) if isinstance(down, dict) else 0),
            "uptime": human_duration(app.core_state()["uptime"]),
            "memory": human_size(STATS.get("mem", 0)),
            "connections": STATS.get("conns", 0),
        }

    def _rules(self):
        data = app.api("GET", "/rules")
        rules = data.get("rules") or []
        out = []
        for r in rules[:600]:
            out.append({
                "type": r.get("type", ""),
                "payload": r.get("payload", ""),
                "proxy": r.get("proxy", ""),
            })
        return {"items": out, "total": len(rules), "providers": list((data.get("providers") or {}).keys())}

    def _profile_add(self, body):
        url = (body.get("url") or "").strip()
        content = body.get("content") or ""
        name = (body.get("name") or "").strip()
        path = (body.get("path") or "").strip()
        if path:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
            name = name or os.path.splitext(os.path.basename(path))[0]
            content = normalize_config(content, app)
            return app.profile_add(name, "", content, kind="local")
        if url:
            text, info = http_fetch_text(url)
            text = normalize_config(text, app)
            if not name:
                name = os.path.splitext(info.get("filename") or "")[0] or \
                    (urllib.parse.urlparse(url).hostname or "远程订阅")
            item = app.profile_add(name, url, text, kind="remote")
            if info.get("userinfo"):
                item["userinfo"] = info["userinfo"]
                app._save_profiles()
            return item
        if content:
            content = normalize_config(content, app)
            return app.profile_add(name or "手动导入", "", content, kind="local")
        raise ValueError("请填写订阅链接，或选择本地配置文件")

    # ── 静态文件 ────────────────────────────────────────────
    def _static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        base = app.ui_source()
        if not base:
            return self._send(500, "界面文件缺失：ui/index.html", "text/plain; charset=utf-8")
        rel = path.lstrip("/")
        if ".." in rel or rel.startswith("/"):
            return self._err("非法路径", 403)
        full = os.path.join(base, rel)
        if not os.path.isfile(full):
            # SPA 回退
            if "." not in os.path.basename(rel):
                full = os.path.join(base, "index.html")
            else:
                return self._err("文件不存在", 404)
        ctype = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".woff2": "font/woff2",
        }.get(os.path.splitext(full)[1].lower(), "application/octet-stream")
        with open(full, "rb") as fh:
            data = fh.read()
        self._send(200, data, ctype)


def pick_local_file():
    """尽量用系统原生对话框选文件，没有就返回空。"""
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
        for cmd in (
            ["zenity", "--file-selection", "--title=选择 Clash 配置文件",
             "--file-filter=*.yaml *.yml *.txt"],
            ["kdialog", "--getopenfilename", os.path.expanduser("~"), "*.yaml *.yml"],
        ):
            if have(cmd[0]):
                code, out, _ = run(cmd, timeout=180)
                if code == 0 and out:
                    return out.strip()
    return ""


def serve(token=""):
    Handler.token = token
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    httpd.daemon_threads = True
    port = httpd.server_address[1]
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, port


def main():
    import argparse

    ap = argparse.ArgumentParser(description="%s - 龙芯图形化 Clash 客户端" % APP_NAME)
    ap.add_argument("--headless", action="store_true", help="只启动后端，用浏览器访问")
    ap.add_argument("--no-window", action="store_true", help="不打开任何窗口（调试用）")
    ap.add_argument("--port", type=int, default=0, help="指定后端端口")
    args = ap.parse_args()

    log("%s %s 启动，架构 %s，Python %s" % (APP_NAME, APP_VERSION, platform.machine(),
                                          platform.python_version()))

    token = rand_secret(24)
    httpd = ThreadingHTTPServer(("127.0.0.1", args.port or 0), Handler)
    Handler.token = token
    port = httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    url = "http://127.0.0.1:%d/#token=%s" % (port, token)
    log("后端已就绪：http://127.0.0.1:%d" % port)

    if args.headless or args.no_window:
        print(url, flush=True)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            app.stop_core()
        return 0

    try:
        from gtk_shell import launch
    except Exception as exc:  # noqa: BLE001
        log("GTK 外壳不可用（%s），改用浏览器模式" % exc, "warn")
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            app.stop_core()
        return 0

    return launch(url, app, token)


if __name__ == "__main__":
    sys.exit(main())
